<script lang="ts">
	import type { CardType } from '$lib/types';
	import { cardTypeColor } from '$lib/utils/colors';

	export let type: CardType;
	export let size: 'sm' | 'md' = 'sm';

	$: classes = cardTypeColor(type);
	$: sizeClasses = size === 'sm' ? 'px-1.5 py-0.5 text-xs' : 'px-2 py-1 text-sm';
</script>

<span class="inline-flex items-center rounded-full font-medium {classes} {sizeClasses}">
	{type.replace('_', ' ')}
</span>
