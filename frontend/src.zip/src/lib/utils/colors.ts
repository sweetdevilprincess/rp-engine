/**
 * Unified color system for the RP Engine frontend.
 * Single source of truth for card type, importance, trust stage, and significance colors.
 */

export interface ColorScheme {
	tailwind: string;
	hex: string;
}

// ── Card type colors ──
export const CARD_TYPE_COLORS: Record<string, ColorScheme> = {
	character:       { tailwind: 'bg-purple-500/20 text-purple-400',  hex: '#a78bfa' },
	npc:             { tailwind: 'bg-green-500/20 text-green-400',    hex: '#4ade80' },
	location:        { tailwind: 'bg-blue-500/20 text-blue-400',      hex: '#60a5fa' },
	secret:          { tailwind: 'bg-red-500/20 text-red-400',        hex: '#f87171' },
	memory:          { tailwind: 'bg-purple-500/20 text-purple-400',  hex: '#c084fc' },
	knowledge:       { tailwind: 'bg-yellow-500/20 text-yellow-400',  hex: '#fbbf24' },
	organization:    { tailwind: 'bg-orange-500/20 text-orange-400',  hex: '#fb923c' },
	plot_thread:     { tailwind: 'bg-pink-500/20 text-pink-400',      hex: '#f472b6' },
	item:            { tailwind: 'bg-teal-500/20 text-teal-400',      hex: '#2dd4bf' },
	lore:            { tailwind: 'bg-indigo-500/20 text-indigo-400',  hex: '#818cf8' },
	plot_arc:        { tailwind: 'bg-rose-500/20 text-rose-400',      hex: '#fb7185' },
	chapter_summary: { tailwind: 'bg-gray-500/20 text-gray-400',      hex: '#94a3b8' },
};

const DEFAULT_COLOR: ColorScheme = { tailwind: 'bg-surface2 text-text-dim', hex: '#94a3b8' };

/** Get Tailwind badge classes for a card type */
export function cardTypeColor(type: string): string {
	return (CARD_TYPE_COLORS[type] ?? DEFAULT_COLOR).tailwind;
}

/** Get hex color for a card type (used in canvas rendering) */
export function cardTypeHex(type: string): string {
	return (CARD_TYPE_COLORS[type] ?? DEFAULT_COLOR).hex;
}

// ── Importance colors ──
export function importanceColor(imp: string | null): string {
	if (!imp) return 'bg-surface2 text-text-dim';
	if (imp === 'primary' || imp === 'critical' || imp === 'pov') return 'bg-accent/20 text-accent';
	if (imp === 'secondary' || imp === 'main' || imp === 'recurring') return 'bg-surface2 text-text';
	return 'bg-surface2 text-text-dim';
}

// ── Trust stage colors ──
export function trustStageColor(stage: string | null): string {
	if (!stage) return 'bg-surface2 text-text-dim';
	const s = stage.toLowerCase();
	if (s.includes('hostile') || s.includes('enemy')) return 'bg-error/20 text-error';
	if (s.includes('distrust') || s.includes('suspicious')) return 'bg-warning/20 text-warning';
	if (s.includes('neutral')) return 'bg-surface2 text-text-dim';
	if (s.includes('acquaint') || s.includes('friendly')) return 'bg-green-500/20 text-green-400';
	if (s.includes('trust') || s.includes('ally') || s.includes('bond')) return 'bg-accent/20 text-accent';
	return 'bg-surface2 text-text-dim';
}

// ── Significance colors ──
export function significanceColor(sig: string | null): string {
	if (!sig) return 'bg-surface2 text-text-dim';
	if (sig === 'major' || sig === 'critical') return 'bg-accent/20 text-accent';
	if (sig === 'moderate') return 'bg-yellow-500/20 text-yellow-400';
	return 'bg-surface2 text-text-dim';
}
