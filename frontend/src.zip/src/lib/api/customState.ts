import { apiFetch } from './client';

export interface CustomStateSchema {
	id: string;
	rp_folder: string | null;
	category: string;
	name: string;
	data_type: string;
	config: Record<string, unknown> | null;
	belongs_to: string | null;
	inject_as: string;
	display_order: number;
}

export interface CustomStateValue {
	schema_id: string;
	entity_id: string | null;
	value: unknown;
	exchange_number: number | null;
	changed_by: string | null;
	reason: string | null;
}

export interface CustomStateSnapshot {
	schemas: CustomStateSchema[];
	values: CustomStateValue[];
}

export interface PresetInfo {
	name: string;
	description: string | null;
	schema_count: number;
}

export async function listSchemas(rp_folder: string): Promise<CustomStateSchema[]> {
	return apiFetch<CustomStateSchema[]>('/api/custom-state/schemas', {
		params: { rp_folder },
		skipRPContext: true,
	});
}

export async function getCustomStateSnapshot(
	rp_folder: string,
	branch = 'main',
): Promise<CustomStateSnapshot> {
	return apiFetch<CustomStateSnapshot>('/api/custom-state', {
		params: { rp_folder, branch },
		skipRPContext: true,
	});
}

export async function setCustomStateValue(
	schema_id: string,
	body: { rp_folder: string; branch?: string; entity_id?: string; value: unknown; reason?: string },
): Promise<CustomStateValue> {
	return apiFetch<CustomStateValue>(`/api/custom-state/${encodeURIComponent(schema_id)}`, {
		method: 'POST',
		body: JSON.stringify({ schema_id, ...body }),
		skipRPContext: true,
	});
}

export async function listPresets(): Promise<PresetInfo[]> {
	return apiFetch<PresetInfo[]>('/api/custom-state/presets/list', {
		skipRPContext: true,
	});
}

export async function applyPreset(
	preset_name: string,
	rp_folder: string,
): Promise<CustomStateSchema[]> {
	return apiFetch<CustomStateSchema[]>(
		`/api/custom-state/presets/${encodeURIComponent(preset_name)}/apply`,
		{
			method: 'POST',
			params: { rp_folder },
			skipRPContext: true,
		},
	);
}
