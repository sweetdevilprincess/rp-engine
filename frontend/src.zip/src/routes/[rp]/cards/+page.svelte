<script lang="ts">
	import { onMount } from 'svelte';
	import { page } from '$app/stores';
	import { listCards, getCard, createCard, updateCard } from '$lib/api/cards';
	import { getFullState } from '$lib/api/state';
	import { addToast } from '$lib/stores/ui';
	import { activeRP } from '$lib/stores/rp';
	import { CARD_TYPES } from '$lib/types/enums';
	import type { CardType } from '$lib/types/enums';
	import type { StoryCardSummary, StoryCardDetail, StoryCardCreate, StoryCardUpdate } from '$lib/types/cards';
	import type { RelationshipDetail } from '$lib/types/state';
	import { cardTypeColor, importanceColor, trustStageColor } from '$lib/utils/colors';

	// ── Card list state ──
	let cards = $state<StoryCardSummary[]>([]);
	let search = $state('');
	let selectedCard = $state<StoryCardDetail | null>(null);
	let loadingCard = $state(false);
	let loadingList = $state(true);

	// ── Editor state ──
	type EditorMode = 'view' | 'edit' | 'create';
	let mode = $state<EditorMode>('view');

	// ── Form fields ──
	let editYaml = $state('');
	let editContent = $state('');
	let saving = $state(false);

	// ── Create mode ──
	let createType = $state<CardType>('npc');
	let createName = $state('');
	let createStep = $state<1 | 2>(1);

	// ── Relationships from state ──
	let relationships = $state<RelationshipDetail[]>([]);

	// Get relationships for the selected card
	let cardRelationships = $derived.by(() => {
		if (!selectedCard) return [];
		const name = selectedCard.name;
		return relationships.filter(r => r.character_a === name || r.character_b === name);
	});

	// ── Derived ──
	let filteredCards = $derived.by(() => {
		return cards.filter(c => {
			if (!search.trim()) return true;
			const q = search.toLowerCase();
			return c.name.toLowerCase().includes(q) || (c.summary ?? '').toLowerCase().includes(q);
		});
	});

	let groupedCards = $derived.by(() => {
		const groups: Record<string, StoryCardSummary[]> = {};
		for (const ct of CARD_TYPES) {
			const matching = filteredCards
				.filter(c => c.card_type === ct)
				.sort((a, b) => a.name.localeCompare(b.name));
			if (matching.length > 0) groups[ct] = matching;
		}
		return groups;
	});

	// ── Init ──
	onMount(async () => {
		await Promise.all([loadCards(), loadRelationships()]);
	});

	async function loadRelationships() {
		try {
			const state = await getFullState();
			relationships = state.relationships;
		} catch {
			// State may not be available yet — relationships just won't show
		}
	}

	async function loadCards() {
		loadingList = true;
		try {
			const res = await listCards();
			cards = res.cards;
		} catch (e: any) {
			addToast(e.message ?? 'Failed to load cards', 'error');
		} finally {
			loadingList = false;
		}
	}

	async function selectCard(card: StoryCardSummary) {
		loadingCard = true;
		mode = 'view';
		try {
			selectedCard = await getCard(card.card_type, card.name);
		} catch (e: any) {
			addToast(e.message ?? 'Failed to load card', 'error');
		} finally {
			loadingCard = false;
		}
	}

	function selectCardByName(name: string) {
		const match = cards.find(c => c.name === name);
		if (match) selectCard(match);
	}

	// ── Editor actions ──
	function enterEditMode() {
		if (!selectedCard) return;
		mode = 'edit';
		editYaml = buildYaml(selectedCard.frontmatter);
		editContent = selectedCard.content;
	}

	function enterCreateMode() {
		mode = 'create';
		createStep = 1;
		createType = 'npc';
		createName = '';
		editYaml = '';
		editContent = '';
		selectedCard = null;
	}

	function startCreateEditor() {
		if (!createName.trim()) {
			addToast('Please enter a card name', 'warning');
			return;
		}
		createStep = 2;
		editYaml = `name: ${createName}`;
		editContent = '';
	}

	function cancelEdit() {
		mode = 'view';
		if (!selectedCard) selectedCard = null;
	}

	async function handleSave() {
		saving = true;
		try {
			const fm = parseYaml(editYaml);
			const content = editContent;

			delete fm['type'];
			delete fm['card_id'];

			if (mode === 'create') {
				const body: StoryCardCreate = { name: createName, frontmatter: fm, content };
				const created = await createCard(createType, body);
				addToast(`Created card: ${created.name}`, 'success');
				await loadCards();
				selectedCard = created;
				mode = 'view';
			} else if (mode === 'edit' && selectedCard) {
				delete fm['name'];
				const body: StoryCardUpdate = { frontmatter: fm, content };
				const updated = await updateCard(selectedCard.card_type, selectedCard.name, body);
				addToast(`Saved card: ${updated.name}`, 'success');
				await loadCards();
				selectedCard = updated;
				mode = 'view';
			}
		} catch (e: any) {
			addToast(e.message ?? 'Save failed', 'error');
		} finally {
			saving = false;
		}
	}

	// ── YAML helpers ──
	function buildYaml(fm: Record<string, unknown>): string {
		const lines: string[] = [];
		for (const [key, val] of Object.entries(fm)) {
			if (val === null || val === undefined) continue;
			if (Array.isArray(val)) {
				if (val.length === 0) {
					lines.push(`${key}: []`);
				} else {
					lines.push(`${key}:`);
					for (const item of val) lines.push(`  - ${item}`);
				}
			} else if (typeof val === 'object') {
				lines.push(`${key}: ${JSON.stringify(val)}`);
			} else {
				lines.push(`${key}: ${val}`);
			}
		}
		return lines.join('\n');
	}

	function parseYaml(yaml: string): Record<string, unknown> {
		const fm: Record<string, unknown> = {};
		let currentKey = '';
		let currentArray: string[] | null = null;

		for (const line of yaml.split('\n')) {
			const trimmed = line.trim();
			if (!trimmed) continue;

			if (trimmed.startsWith('- ') && currentKey) {
				if (!currentArray) currentArray = [];
				currentArray.push(trimmed.slice(2).trim());
				continue;
			}

			if (currentArray && currentKey) {
				fm[currentKey] = currentArray;
				currentArray = null;
			}

			const colonIdx = trimmed.indexOf(':');
			if (colonIdx === -1) continue;

			const key = trimmed.slice(0, colonIdx).trim();
			const val = trimmed.slice(colonIdx + 1).trim();
			currentKey = key;

			if (val === '' || val === '[]') {
				if (val === '[]') fm[key] = [];
				continue;
			}

			if (val.startsWith('{') || val.startsWith('[')) {
				try { fm[key] = JSON.parse(val); continue; } catch {}
			}

			if (val === 'true') { fm[key] = true; continue; }
			if (val === 'false') { fm[key] = false; continue; }
			if (val === 'null') { fm[key] = null; continue; }

			const num = Number(val);
			if (!isNaN(num) && val !== '') { fm[key] = num; continue; }

			fm[key] = val;
		}

		if (currentArray && currentKey) {
			fm[currentKey] = currentArray;
		}

		return fm;
	}
</script>

<!-- 3-panel layout -->
<div class="flex gap-2" style="height: calc(100vh - 120px)">

	<!-- ═══ LEFT: Card List ═══ -->
	<div class="w-64 shrink-0 bg-surface border border-border-custom rounded-lg overflow-hidden flex flex-col">
		<!-- Search -->
		<div class="p-2 border-b border-border-custom">
			<input
				type="text"
				bind:value={search}
				placeholder="Search cards..."
				class="w-full bg-surface2 border border-border-custom rounded px-2 py-1 text-xs text-text
					placeholder:text-text-dim/50 focus:outline-none focus:ring-1 focus:ring-accent"
			/>
		</div>

		<!-- Grouped card list -->
		<div class="flex-1 overflow-y-auto">
			{#if loadingList}
				<div class="p-3 text-xs text-text-dim text-center">Loading cards...</div>
			{:else if Object.keys(groupedCards).length === 0}
				<div class="p-3 text-xs text-text-dim text-center">No cards found.</div>
			{:else}
				{#each Object.entries(groupedCards) as [type, typeCards]}
					<details open>
						<summary class="flex items-center gap-2 px-2 py-1.5 cursor-pointer hover:bg-surface2 text-xs border-b border-border-custom/50 select-none">
							<span class="px-1.5 py-0.5 rounded-full text-xs font-medium {cardTypeColor(type)}">{type.replace('_', ' ')}</span>
							<span class="text-text-dim">({typeCards.length})</span>
						</summary>
						{#each typeCards as card}
							<button
								class="w-full text-left px-3 py-1 text-xs border-b border-border-custom/30 hover:bg-surface2 transition-colors flex items-center gap-1.5
									{selectedCard?.name === card.name && selectedCard?.card_type === card.card_type ? 'bg-accent/10' : ''}"
								onclick={() => selectCard(card)}
							>
								<span class="text-text truncate flex-1">{card.name}</span>
								{#if card.importance}
									<span class="px-1 py-0.5 rounded text-[10px] leading-none {importanceColor(card.importance)}">{card.importance}</span>
								{/if}
								{#if card.connection_count > 0}
									<span class="text-text-dim text-[10px] shrink-0">{card.connection_count}</span>
								{/if}
							</button>
						{/each}
					</details>
				{/each}
			{/if}
		</div>

		<!-- New Card button -->
		<div class="p-2 border-t border-border-custom">
			<button
				class="w-full px-3 py-1.5 text-xs rounded bg-accent/20 text-accent hover:bg-accent/30 transition-colors"
				onclick={enterCreateMode}
			>
				+ New Card
			</button>
		</div>
	</div>

	<!-- ═══ CENTER: Card Editor ═══ -->
	<div class="flex-1 min-w-0 bg-surface border border-border-custom rounded-lg overflow-hidden flex flex-col">

		{#if mode === 'create' && createStep === 1}
			<!-- Create step 1: pick type + name -->
			<div class="p-4 space-y-3">
				<h2 class="text-sm font-medium text-text">New Card</h2>
				<div class="space-y-2">
					<label class="block text-xs text-text-dim">
						Card Type
						<select
							bind:value={createType}
							class="mt-1 w-full bg-surface2 border border-border-custom rounded px-2 py-1.5 text-xs text-text
								focus:outline-none focus:ring-1 focus:ring-accent"
						>
							{#each CARD_TYPES as ct}
								<option value={ct}>{ct.replace('_', ' ')}</option>
							{/each}
						</select>
					</label>
					<label class="block text-xs text-text-dim">
						Name
						<input
							type="text"
							bind:value={createName}
							placeholder="Card name..."
							class="mt-1 w-full bg-surface2 border border-border-custom rounded px-2 py-1.5 text-xs text-text
								placeholder:text-text-dim/50 focus:outline-none focus:ring-1 focus:ring-accent"
							onkeydown={(e) => e.key === 'Enter' && startCreateEditor()}
						/>
					</label>
				</div>
				<div class="flex gap-2">
					<button
						class="px-3 py-1.5 text-xs rounded bg-accent/20 text-accent hover:bg-accent/30 transition-colors"
						onclick={startCreateEditor}
					>
						Next
					</button>
					<button
						class="px-3 py-1.5 text-xs rounded bg-surface2 text-text-dim hover:text-text transition-colors"
						onclick={cancelEdit}
					>
						Cancel
					</button>
				</div>
			</div>

		{:else if mode === 'view' && !selectedCard && !loadingCard}
			<!-- Empty state -->
			<div class="flex-1 flex items-center justify-center text-xs text-text-dim">
				Select a card to view details
			</div>

		{:else if loadingCard}
			<div class="flex-1 flex items-center justify-center text-xs text-text-dim">
				Loading card...
			</div>

		{:else if mode === 'view' && selectedCard}
			<!-- View mode -->
			<div class="flex-1 overflow-y-auto p-4 space-y-3">
				<!-- Header -->
				<div class="flex items-center gap-2">
					<span class="px-1.5 py-0.5 rounded-full text-xs font-medium {cardTypeColor(selectedCard.card_type)}">{selectedCard.card_type.replace('_', ' ')}</span>
					<h2 class="text-sm font-medium text-text">{selectedCard.name}</h2>
					{#if selectedCard.importance}
						<span class="px-1.5 py-0.5 rounded text-[10px] {importanceColor(selectedCard.importance)}">{selectedCard.importance}</span>
					{/if}
					<div class="flex-1"></div>
					<button
						class="px-3 py-1 text-xs rounded bg-accent/20 text-accent hover:bg-accent/30 transition-colors"
						onclick={enterEditMode}
					>
						Edit
					</button>
				</div>

				<!-- Frontmatter -->
				{#if Object.keys(selectedCard.frontmatter).length > 0}
					<div>
						<p class="text-[10px] text-text-dim uppercase tracking-wider mb-1">Frontmatter</p>
						<div class="space-y-0.5">
							{#each Object.entries(selectedCard.frontmatter) as [key, val]}
								<div class="flex gap-2 text-xs">
									<span class="text-text-dim shrink-0 w-32 truncate">{key}</span>
									<span class="text-text break-all">{typeof val === 'object' ? JSON.stringify(val) : String(val ?? '')}</span>
								</div>
							{/each}
						</div>
					</div>
				{/if}

				<!-- Body content -->
				{#if selectedCard.content}
					<div>
						<p class="text-[10px] text-text-dim uppercase tracking-wider mb-1">Content</p>
						<div class="text-xs text-text-dim leading-relaxed whitespace-pre-wrap max-h-96 overflow-y-auto bg-surface2 rounded p-2">
							{selectedCard.content}
						</div>
					</div>
				{/if}
			</div>

		{:else if mode === 'edit' || (mode === 'create' && createStep === 2)}
			<!-- Edit / Create editor — two textareas -->
			<div class="flex flex-col flex-1 overflow-hidden">
				<!-- Header -->
				<div class="flex items-center px-3 py-2 border-b border-border-custom">
					<span class="text-xs font-medium text-text">
						{mode === 'create' ? `Creating ${createType.replace('_', ' ')}: ${createName}` : `Editing: ${selectedCard?.name ?? ''}`}
					</span>
				</div>

				<div class="flex-1 overflow-y-auto p-3 space-y-3">
					<!-- YAML frontmatter (collapsible) -->
					<details class="group">
						<summary class="flex items-center gap-2 cursor-pointer select-none mb-1">
							<svg class="w-3 h-3 text-text-dim transition-transform group-open:rotate-90" viewBox="0 0 16 16" fill="currentColor">
								<path d="M6 4l4 4-4 4" />
							</svg>
							<span class="text-[10px] text-text-dim uppercase tracking-wider">Frontmatter (YAML)</span>
						</summary>
						<div class="px-2 py-1.5 mb-1.5 bg-warning/10 border border-warning/20 rounded text-[10px] text-warning leading-relaxed">
							Strict YAML formatting — incorrect syntax will cause save errors. Only edit if you know what you're doing.
						</div>
						<textarea
							bind:value={editYaml}
							rows="8"
							class="w-full bg-surface2 border border-border-custom rounded px-2 py-1.5 text-xs text-text font-mono
								focus:outline-none focus:ring-1 focus:ring-accent resize-y"
							spellcheck="false"
						></textarea>
					</details>

					<!-- Body content -->
					<div class="flex-1 flex flex-col">
						<div class="mb-1">
							<span class="text-[10px] text-text-dim uppercase tracking-wider">Body Content</span>
						</div>
						<textarea
							bind:value={editContent}
							rows="20"
							class="w-full flex-1 bg-surface2 border border-border-custom rounded px-2 py-1.5 text-xs text-text
								focus:outline-none focus:ring-1 focus:ring-accent resize-y"
						></textarea>
					</div>
				</div>

				<!-- Save / Cancel bar -->
				<div class="flex items-center gap-2 px-3 py-2 border-t border-border-custom">
					<button
						class="px-4 py-1.5 text-xs rounded bg-accent text-white hover:bg-accent/90 transition-colors disabled:opacity-50"
						onclick={handleSave}
						disabled={saving}
					>
						{saving ? 'Saving...' : mode === 'create' ? 'Create' : 'Save'}
					</button>
					<button
						class="px-3 py-1.5 text-xs rounded bg-surface2 text-text-dim hover:text-text transition-colors"
						onclick={cancelEdit}
					>
						Cancel
					</button>
				</div>
			</div>
		{/if}
	</div>

	<!-- ═══ RIGHT: Connections ═══ -->
	<div class="w-72 shrink-0 bg-surface border border-border-custom rounded-lg overflow-hidden flex flex-col">
		<div class="px-3 py-2 border-b border-border-custom">
			<span class="text-xs font-semibold text-text-dim uppercase tracking-wider">Connections</span>
		</div>

		<div class="flex-1 overflow-y-auto p-2">
			{#if !selectedCard && mode !== 'create'}
				<div class="text-xs text-text-dim text-center mt-4">Select a card to see its connections</div>
			{:else if selectedCard}
				<!-- Relationships with trust scores -->
				{#if cardRelationships.length > 0}
					<div class="mb-3">
						<p class="text-[10px] text-text-dim uppercase tracking-wider px-2 mb-1">Relationships</p>
						<div class="space-y-0.5">
							{#each cardRelationships as rel}
								{@const otherName = rel.character_a === selectedCard.name ? rel.character_b : rel.character_a}
								<button
									class="flex items-center gap-1.5 text-xs hover:bg-surface2 rounded px-2 py-1.5 w-full text-left transition-colors"
									onclick={() => selectCardByName(otherName)}
								>
									<span class="text-accent truncate flex-1">{otherName}</span>
									<span class="font-mono text-[10px] shrink-0 {rel.live_trust_score > 0 ? 'text-success' : rel.live_trust_score < 0 ? 'text-error' : 'text-text-dim'}">
										{rel.live_trust_score > 0 ? '+' : ''}{rel.live_trust_score}
									</span>
									<span class="px-1 py-0.5 rounded text-[10px] shrink-0 {trustStageColor(rel.trust_stage)}">
										{rel.trust_stage}
									</span>
								</button>
							{/each}
						</div>
					</div>
				{/if}

				<!-- Entity connections -->
				{#if selectedCard.connections.length > 0}
					<div>
						<p class="text-[10px] text-text-dim uppercase tracking-wider px-2 mb-1">Card Links</p>
						<div class="space-y-0.5">
							{#each selectedCard.connections as conn}
								<button
									class="flex items-center gap-1.5 text-xs hover:bg-surface2 rounded px-2 py-1 w-full text-left transition-colors"
									onclick={() => selectCardByName(conn.to_entity)}
								>
									<span class="text-text-dim text-[10px] shrink-0">{conn.connection_type}</span>
									<span class="text-accent truncate">{conn.to_entity}</span>
								</button>
							{/each}
						</div>
					</div>
				{/if}

				{#if cardRelationships.length === 0 && selectedCard.connections.length === 0}
					<div class="text-xs text-text-dim text-center mt-4">No connections</div>
				{/if}
			{/if}
		</div>

		<!-- Trust deep-link for NPC/character cards -->
		{#if selectedCard && (selectedCard.card_type === 'npc' || selectedCard.card_type === 'character')}
			<div class="p-2 border-t border-border-custom">
				<a
					href="/{$activeRP?.rp_folder ?? $page.params.rp}/dashboard?tool=trust&npc={encodeURIComponent(selectedCard.name)}"
					class="flex items-center justify-center gap-1.5 px-3 py-1.5 text-xs rounded bg-accent/20 text-accent hover:bg-accent/30 transition-colors"
				>
					View Trust
				</a>
			</div>
		{/if}
	</div>
</div>
