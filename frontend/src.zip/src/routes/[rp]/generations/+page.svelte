<script lang="ts">
	import { suggestCard, listCards, createCard, reindex } from '$lib/api/cards';
	import { addToast } from '$lib/stores/ui';
	import type { StoryCardSummary, SuggestCardResponse, CardType } from '$lib/types';
	import { CARD_TYPES } from '$lib/types';

	// Form inputs
	let entityName = '';
	let cardType: CardType = 'npc';
	let prompt = '';
	let buildOnPrevious = false;

	// Relations
	let relations: StoryCardSummary[] = [];
	let relationSearch = '';
	let searchResults: StoryCardSummary[] = [];
	let showSearchDropdown = false;
	let allCards: StoryCardSummary[] = [];
	let cardsLoaded = false;

	// Generation state
	let generating = false;
	let output: SuggestCardResponse | null = null;
	let previousOutput: SuggestCardResponse | null = null;

	// Save state
	let saving = false;

	// Alter mode
	let altering = false;

	// Debounce timer
	let searchTimer: ReturnType<typeof setTimeout> | null = null;

	async function ensureCardsLoaded() {
		if (cardsLoaded) return;
		try {
			const resp = await listCards();
			allCards = resp.cards;
			cardsLoaded = true;
		} catch (err: any) {
			addToast(err.message ?? 'Failed to load cards', 'error');
		}
	}

	function handleSearchInput() {
		if (searchTimer) clearTimeout(searchTimer);
		searchTimer = setTimeout(async () => {
			await ensureCardsLoaded();
			const q = relationSearch.toLowerCase().trim();
			if (!q) {
				searchResults = [];
				showSearchDropdown = false;
				return;
			}
			const addedNames = new Set(relations.map((r) => r.name));
			searchResults = allCards
				.filter(
					(c) =>
						!addedNames.has(c.name) &&
						(c.name.toLowerCase().includes(q) ||
							c.card_type.toLowerCase().includes(q) ||
							c.aliases.some((a) => a.toLowerCase().includes(q)))
				)
				.slice(0, 10);
			showSearchDropdown = searchResults.length > 0;
		}, 300);
	}

	function addRelation(card: StoryCardSummary) {
		relations = [...relations, card];
		relationSearch = '';
		searchResults = [];
		showSearchDropdown = false;
	}

	function removeRelation(name: string) {
		relations = relations.filter((r) => r.name !== name);
	}

	function buildContext(): string {
		const parts: string[] = [];

		// Relations context
		if (relations.length > 0) {
			const relLines = relations.map(
				(r) => `- ${r.name} (${r.card_type})${r.summary ? ': ' + r.summary : ''}`
			);
			parts.push('Related entities:\n' + relLines.join('\n'));
		}

		// Build on previous
		if (buildOnPrevious && previousOutput) {
			parts.push('Previous generation:\n' + previousOutput.markdown);
		}

		// User prompt
		if (prompt.trim()) {
			parts.push(prompt.trim());
		}

		return parts.join('\n\n');
	}

	async function generate() {
		if (!entityName.trim()) {
			addToast('Entity name is required', 'warning');
			return;
		}
		generating = true;
		try {
			const context = buildContext() || undefined;
			const result = await suggestCard(entityName.trim(), cardType, context);
			// Store previous for "build on previous"
			if (output) previousOutput = output;
			output = result;
		} catch (err: any) {
			addToast(err.message ?? 'Generation failed', 'error');
		} finally {
			generating = false;
		}
	}

	async function alterOutput() {
		if (!output) {
			addToast('Nothing to alter — generate first', 'warning');
			return;
		}
		if (!prompt.trim()) {
			addToast('Enter alteration instructions in the prompt', 'warning');
			return;
		}
		altering = true;
		try {
			const alterContext =
				'Modify the following existing card based on these instructions. Do not regenerate from scratch:\n' +
				output.markdown +
				'\n\nInstructions: ' +
				prompt.trim();
			const result = await suggestCard(entityName.trim(), cardType, alterContext);
			previousOutput = output;
			output = result;
		} catch (err: any) {
			addToast(err.message ?? 'Alteration failed', 'error');
		} finally {
			altering = false;
		}
	}

	async function saveCard() {
		if (!output) return;
		saving = true;
		try {
			await createCard(output.card_type, {
				name: output.entity_name,
				content: output.markdown,
			});
			await reindex();
			addToast(`Card "${output.entity_name}" saved and indexed`, 'success');
			// Refresh card cache for relations search
			cardsLoaded = false;
		} catch (err: any) {
			addToast(err.message ?? 'Save failed', 'error');
		} finally {
			saving = false;
		}
	}

	function handleSearchKeydown(e: KeyboardEvent) {
		if (e.key === 'Escape') {
			showSearchDropdown = false;
		}
	}

	function handleSearchBlur() {
		// Delay to allow click on dropdown item
		setTimeout(() => (showSearchDropdown = false), 200);
	}
</script>

<div class="flex gap-3 h-full">
	<!-- Left: Output panel -->
	<div class="flex-[3] min-w-0 flex flex-col gap-2">
		<div class="bg-surface rounded border border-border-custom p-3 flex-1 flex flex-col">
			<div class="flex items-center justify-between mb-2">
				<h2 class="text-xs font-semibold text-text">Output</h2>
				{#if output}
					<span class="text-xs text-text-dim">
						via {output.model_used}
					</span>
				{/if}
			</div>

			{#if generating || altering}
				<div class="flex-1 flex items-center justify-center">
					<div class="text-sm text-text-dim animate-pulse">
						{altering ? 'Altering...' : 'Generating...'}
					</div>
				</div>
			{:else if output}
				<div class="flex-1 overflow-auto">
					<pre class="text-sm text-text whitespace-pre-wrap break-words font-mono leading-relaxed">{output.markdown}</pre>
				</div>
			{:else}
				<div class="flex-1 flex items-center justify-center">
					<p class="text-sm text-text-dim">No output yet. Configure and generate a card.</p>
				</div>
			{/if}

			{#if output && !generating && !altering}
				<div class="mt-2 pt-2 border-t border-border-custom">
					<button
						class="bg-accent hover:bg-accent-hover text-white text-sm font-medium py-2 px-4 rounded-md
							transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
						on:click={saveCard}
						disabled={saving}
					>
						{saving ? 'Saving...' : 'Save Card'}
					</button>
				</div>
			{/if}
		</div>
	</div>

	<!-- Right: Controls panel -->
	<div class="flex-[2] min-w-0 flex flex-col gap-2">
		<!-- Relations -->
		<div class="bg-surface rounded border border-border-custom p-3 space-y-2">
			<h3 class="text-xs font-semibold text-text">Relations</h3>

			<!-- Search -->
			<div class="relative">
				<input
					type="text"
					bind:value={relationSearch}
					on:input={handleSearchInput}
					on:keydown={handleSearchKeydown}
					on:blur={handleSearchBlur}
					on:focus={handleSearchInput}
					placeholder="Search & add cards..."
					class="w-full bg-surface2 border border-border-custom rounded-md px-3 py-2 text-sm text-text
						placeholder:text-text-dim/50 focus:outline-none focus:ring-1 focus:ring-accent"
				/>

				{#if showSearchDropdown}
					<div class="absolute z-10 top-full left-0 right-0 mt-1 bg-surface border border-border-custom rounded-md shadow-lg max-h-48 overflow-auto">
						{#each searchResults as card}
							<button
								class="w-full flex items-center gap-2 px-3 py-1.5 text-left hover:bg-surface2 transition-colors"
								on:mousedown|preventDefault={() => addRelation(card)}
							>
								<span class="text-xs bg-surface2 text-text-dim px-1.5 py-0.5 rounded">{card.card_type}</span>
								<span class="text-sm text-text truncate">{card.name}</span>
							</button>
						{/each}
					</div>
				{/if}
			</div>

			<!-- Added relations chips -->
			{#if relations.length > 0}
				<div class="flex flex-wrap gap-1.5">
					{#each relations as rel}
						<span class="inline-flex items-center gap-1 text-xs bg-surface2 text-text px-2 py-1 rounded">
							<span class="text-text-dim">{rel.card_type}</span>
							<span>{rel.name}</span>
							<button
								class="text-text-dim hover:text-error transition-colors ml-0.5"
								on:click={() => removeRelation(rel.name)}
								aria-label="Remove {rel.name}"
							>&times;</button>
						</span>
					{/each}
				</div>
			{/if}
		</div>

		<!-- Card Type + Entity Name -->
		<div class="bg-surface rounded border border-border-custom p-3 space-y-2">
			<div class="space-y-1">
				<label for="card-type" class="text-xs font-semibold text-text">Card Type</label>
				<select
					id="card-type"
					bind:value={cardType}
					class="w-full bg-surface2 border border-border-custom rounded-md px-3 py-2 text-sm text-text
						focus:outline-none focus:ring-1 focus:ring-accent"
				>
					{#each CARD_TYPES as ct}
						<option value={ct}>{ct}</option>
					{/each}
				</select>
			</div>

			<div class="space-y-1">
				<label for="entity-name" class="text-xs font-semibold text-text">Entity Name</label>
				<input
					id="entity-name"
					type="text"
					bind:value={entityName}
					placeholder="e.g. Marco, The Gilded Rose..."
					class="w-full bg-surface2 border border-border-custom rounded-md px-3 py-2 text-sm text-text
						placeholder:text-text-dim/50 focus:outline-none focus:ring-1 focus:ring-accent"
				/>
			</div>
		</div>

		<!-- Prompt -->
		<div class="bg-surface rounded border border-border-custom p-3 space-y-2">
			<label for="prompt" class="text-xs font-semibold text-text">Prompt</label>
			<textarea
				id="prompt"
				bind:value={prompt}
				placeholder="Additional context or instructions for the AI..."
				rows="5"
				class="w-full bg-surface2 border border-border-custom rounded-md px-3 py-2 text-sm text-text
					placeholder:text-text-dim/50 focus:outline-none focus:ring-1 focus:ring-accent resize-none"
			></textarea>

		</div>

		<!-- Build on Previous + Action buttons -->
		<div class="flex flex-col gap-2">
			<button
				class="w-full flex items-center justify-between px-4 py-2 rounded-md text-sm font-medium transition-all border
					{buildOnPrevious
						? 'bg-accent/15 text-accent border-accent/30'
						: 'bg-surface2 text-text-dim border-border-custom/50 hover:text-text hover:border-border-custom'}
					{!previousOutput ? 'opacity-50 cursor-not-allowed' : 'cursor-pointer'}"
				on:click={() => { if (previousOutput) buildOnPrevious = !buildOnPrevious; }}
				disabled={!previousOutput}
				title={previousOutput ? (buildOnPrevious ? 'Click to disable' : 'Click to build on previous output') : 'Generate first to enable'}
			>
				<span>Build on Previous</span>
				{#if buildOnPrevious && previousOutput}
					<span class="text-xs bg-accent/10 px-2 py-0.5 rounded-full truncate max-w-[140px]">
						{previousOutput.entity_name}
					</span>
				{:else}
					<span class="w-8 h-4 rounded-full transition-colors {buildOnPrevious ? 'bg-accent' : 'bg-surface2 border border-border-custom'}">
						<span class="block w-3 h-3 rounded-full bg-text mt-0.5 transition-transform {buildOnPrevious ? 'translate-x-4' : 'translate-x-0.5'}"></span>
					</span>
				{/if}
			</button>
			<button
				class="w-full bg-accent hover:bg-accent-hover text-white text-sm font-medium py-2 px-4 rounded-md
					transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
				on:click={generate}
				disabled={generating || altering || !entityName.trim()}
			>
				{generating ? 'Generating...' : 'Generate'}
			</button>

			<button
				class="w-full bg-surface2 hover:bg-border-custom text-text text-sm font-medium py-2 px-4 rounded-md
					transition-colors border border-border-custom disabled:opacity-50 disabled:cursor-not-allowed"
				on:click={alterOutput}
				disabled={generating || altering || !output}
			>
				{altering ? 'Altering...' : 'Alter Output'}
			</button>
		</div>
	</div>
</div>
