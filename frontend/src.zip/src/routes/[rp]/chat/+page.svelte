<script lang="ts">
	import { onMount, tick } from 'svelte';
	import { activeRP } from '$lib/stores/rp';
	import { addToast } from '$lib/stores/ui';
	import { getFullState } from '$lib/api/state';
	import { sendChatMessage, type ChatMessage } from '$lib/api/chat';
	import type { StateSnapshot } from '$lib/types';

	// ── Chat state ────────────────────────────────────────────
	let messages: ChatMessage[] = [];
	let userInput = '';
	let sending = false;
	let chatLog: HTMLDivElement;

	// ── Stats panel ───────────────────────────────────────────
	let showStats = true;
	let stateSnapshot: StateSnapshot | null = null;
	let loadingState = false;

	onMount(async () => {
		await loadState();
	});

	async function loadState() {
		loadingState = true;
		try {
			stateSnapshot = await getFullState();
		} catch {
			// Stats panel is optional — don't fail the page
		} finally {
			loadingState = false;
		}
	}

	async function handleSend() {
		const msg = userInput.trim();
		if (!msg || sending) return;

		// Add user message
		messages = [...messages, { role: 'user', content: msg, timestamp: new Date().toISOString() }];
		userInput = '';
		sending = true;

		await tick();
		scrollToBottom();

		try {
			const result = await sendChatMessage(msg);
			messages = [...messages, { role: 'assistant', content: result.response, timestamp: new Date().toISOString() }];
			// Refresh state after each exchange
			loadState();
		} catch (e: any) {
			addToast(e.message ?? 'Chat failed', 'error');
		} finally {
			sending = false;
			await tick();
			scrollToBottom();
		}
	}

	function scrollToBottom() {
		if (chatLog) chatLog.scrollTop = chatLog.scrollHeight;
	}

	function handleKeydown(e: KeyboardEvent) {
		if (e.key === 'Enter' && !e.shiftKey) {
			e.preventDefault();
			handleSend();
		}
	}

	function fmt(iso: string) {
		return new Date(iso).toLocaleTimeString(undefined, { hour: '2-digit', minute: '2-digit' });
	}
</script>

<div class="relative h-[calc(100vh-160px)] flex flex-col bg-surface border border-border-custom rounded-lg overflow-hidden">

	<!-- Floating stats panel (top-left overlay) -->
	{#if showStats}
		<div class="absolute top-3 left-3 z-10 bg-surface/95 backdrop-blur-sm border border-border-custom rounded-lg shadow-lg w-56 max-h-[70%] overflow-y-auto">
			<div class="px-3 py-2.5 border-b border-border-custom flex items-center justify-between sticky top-0 bg-surface/95 backdrop-blur-sm">
				<span class="text-xs font-semibold text-text-dim uppercase tracking-wider">Stats</span>
				<button
					class="text-xs text-text-dim hover:text-text transition-colors"
					on:click={() => (showStats = false)}
				>Hide</button>
			</div>
			<div class="p-3 space-y-3">
				{#if loadingState}
					<p class="text-xs text-text-dim">Loading...</p>
				{:else if stateSnapshot}
					<!-- Scene -->
					<div>
						<p class="text-xs text-text-dim uppercase tracking-wider mb-1">Scene</p>
						<div class="space-y-1 text-xs">
							{#if stateSnapshot.scene.location}
								<div class="flex justify-between">
									<span class="text-text-dim">Location</span>
									<span class="text-text">{stateSnapshot.scene.location}</span>
								</div>
							{/if}
							{#if stateSnapshot.scene.time_of_day}
								<div class="flex justify-between">
									<span class="text-text-dim">Time</span>
									<span class="text-text">{stateSnapshot.scene.time_of_day}</span>
								</div>
							{/if}
							{#if stateSnapshot.scene.mood}
								<div class="flex justify-between">
									<span class="text-text-dim">Mood</span>
									<span class="text-text">{stateSnapshot.scene.mood}</span>
								</div>
							{/if}
						</div>
					</div>

					<!-- Characters -->
					{#if Object.keys(stateSnapshot.characters).length > 0}
						<div>
							<p class="text-xs text-text-dim uppercase tracking-wider mb-1">Characters</p>
							<div class="space-y-1.5">
								{#each Object.entries(stateSnapshot.characters) as [name, char]}
									<div class="text-xs">
										<span class="text-text font-medium">{name}</span>
										{#if char.emotional_state}
											<span class="text-text-dim italic ml-1">{char.emotional_state}</span>
										{/if}
										{#if char.conditions.length > 0}
											<div class="flex flex-wrap gap-0.5 mt-0.5">
												{#each char.conditions as cond}
													<span class="bg-surface2 px-1 py-0.5 rounded text-[10px] text-text-dim">{cond}</span>
												{/each}
											</div>
										{/if}
									</div>
								{/each}
							</div>
						</div>
					{/if}
				{:else}
					<p class="text-xs text-text-dim">No state data available.</p>
				{/if}
			</div>
		</div>
	{/if}

	<!-- Header -->
	<div class="px-4 py-2.5 border-b border-border-custom flex items-center justify-between shrink-0">
		<div class="flex items-center gap-2">
			<button
				class="text-xs px-2 py-1 rounded transition-colors {showStats
					? 'bg-accent/20 text-accent'
					: 'text-text-dim hover:text-text'}"
				on:click={() => (showStats = !showStats)}
			>Stats</button>
			<span class="text-sm font-medium text-text">{$activeRP?.rp_folder ?? 'Chat'}</span>
			<span class="text-xs text-text-dim">
				{messages.length} message{messages.length !== 1 ? 's' : ''}
			</span>
		</div>
		<span class="text-xs text-text-dim bg-surface2 px-2 py-0.5 rounded">stub mode</span>
	</div>

	<!-- Chat log (centered) -->
	<div
		bind:this={chatLog}
		class="flex-1 overflow-y-auto p-4"
	>
		<div class="max-w-2xl mx-auto space-y-4">
			{#if messages.length === 0}
				<div class="flex items-center justify-center h-full text-sm text-text-dim" style="min-height: 200px">
					Start a conversation. Type a message below.
				</div>
			{:else}
				{#each messages as msg}
					<div class="flex gap-3 {msg.role === 'user' ? 'justify-end' : ''}">
						<div class="max-w-[80%] {msg.role === 'user'
							? 'bg-accent/15 border-accent/20'
							: 'bg-surface2 border-border-custom/50'} border rounded-lg px-4 py-3">
							<p class="text-sm text-text whitespace-pre-wrap">{msg.content}</p>
							<p class="text-[10px] text-text-dim mt-1.5">{fmt(msg.timestamp)}</p>
						</div>
					</div>
				{/each}
				{#if sending}
					<div class="flex gap-3">
						<div class="bg-surface2 border border-border-custom/50 rounded-lg px-4 py-3">
							<p class="text-sm text-text-dim animate-pulse">Generating...</p>
						</div>
					</div>
				{/if}
			{/if}
		</div>
	</div>

	<!-- Input bar (centered) -->
	<div class="border-t border-border-custom shrink-0">
		<div class="max-w-2xl mx-auto px-4 py-3 flex items-end gap-2">
			<textarea
				bind:value={userInput}
				on:keydown={handleKeydown}
				placeholder="Type a message..."
				rows="1"
				class="flex-1 bg-surface2 border border-border-custom rounded-lg px-3 py-2 text-sm text-text
					placeholder:text-text-dim/50 focus:outline-none focus:ring-1 focus:ring-accent resize-none
					max-h-32 overflow-y-auto"
			></textarea>
			<button
				class="bg-accent hover:bg-accent-hover text-white text-sm font-medium py-2 px-4 rounded-lg
					transition-colors disabled:opacity-50 disabled:cursor-not-allowed shrink-0"
				on:click={handleSend}
				disabled={sending || !userInput.trim()}
			>
				Send
			</button>
		</div>
	</div>
</div>
