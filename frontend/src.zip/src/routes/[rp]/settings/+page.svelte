<script lang="ts">
	import { onMount } from 'svelte';
	import { page } from '$app/stores';
	import { getGuidelines, updateGuidelines } from '$lib/api/context';
	import { getFullState, updateCharacter, updateScene } from '$lib/api/state';
	import { getCustomStateSnapshot, setCustomStateValue, listPresets, applyPreset, type CustomStateSnapshot, type PresetInfo } from '$lib/api/customState';
	import { addToast } from '$lib/stores/ui';
	import { activeBranch } from '$lib/stores/rp';
	import { get } from 'svelte/store';
	import type { GuidelinesResponse, StateSnapshot, CharacterDetail, SceneStateDetail } from '$lib/types';

	const sections = [
		{ id: 'guidelines',   label: 'Story Guidelines' },
		{ id: 'characters',   label: 'Characters'       },
		{ id: 'scene',        label: 'Scene State'      },
		{ id: 'customstate',  label: 'Custom State'     },
	];

	let activeSection = 'guidelines';
	let rpFolder = '';

	// Guidelines
	let guidelines: GuidelinesResponse | null = null;
	let guidelinesLoading = true;
	let guidelinesSaving = false;
	let gPovMode: string = 'single';
	let gPovCharacter = '';
	let gDualCharacters = '';
	let gNarrativeVoice = 'third';
	let gTense = 'past';
	let gTone = '';
	let gScenePacing = 'moderate';
	let gResponseLength = 'medium';
	let gIntegrateUserNarrative = true;
	let gPreserveUserDetails = true;
	let gSensitiveThemes = '';
	let gHardLimits = '';

	// State
	let stateSnapshot: StateSnapshot | null = null;
	let stateLoading = true;
	let characters: Record<string, CharacterDetail> = {};
	let scene: SceneStateDetail = { location: null, time_of_day: null, mood: null, in_story_timestamp: null };

	// Inline editing
	let editingChar: string | null = null;
	let editCharLocation = '';
	let editCharEmotional = '';
	let charSaving = false;
	let sceneSaving = false;

	// Custom State
	let customState: CustomStateSnapshot | null = null;
	let customStateLoading = true;
	let presets: PresetInfo[] = [];
	let selectedPreset = '';
	let applyingPreset = false;
	let editingValue: { schemaId: string; entityId: string | null } | null = null;
	let editValueStr = '';
	let valueSaving = false;

	$: rpFolder = $page.params.rp ?? '';

	onMount(async () => {
		await Promise.all([loadGuidelines(), loadState(), loadCustomState()]);
	});

	async function loadGuidelines() {
		guidelinesLoading = true;
		try {
			const g = await getGuidelines(rpFolder);
			guidelines = g;
			gPovMode = g.pov_mode ?? 'single';
			gPovCharacter = g.pov_character ?? '';
			gDualCharacters = (g.dual_characters ?? []).join(', ');
			gNarrativeVoice = g.narrative_voice ?? 'third';
			gTense = g.tense ?? 'past';
			gTone = Array.isArray(g.tone) ? g.tone.join(', ') : (g.tone ?? '');
			gScenePacing = g.scene_pacing ?? 'moderate';
			gResponseLength = g.response_length ?? 'medium';
			gIntegrateUserNarrative = g.integrate_user_narrative ?? true;
			gPreserveUserDetails = g.preserve_user_details ?? true;
			gSensitiveThemes = (g.sensitive_themes ?? []).join(', ');
			gHardLimits = Array.isArray(g.hard_limits) ? g.hard_limits.join(', ') : (g.hard_limits ?? '');
		} catch (e: any) {
			addToast(`Failed to load guidelines: ${e.message}`, 'error');
		} finally {
			guidelinesLoading = false;
		}
	}

	async function saveGuidelines() {
		guidelinesSaving = true;
		try {
			const body: Record<string, unknown> = {
				pov_mode: gPovMode,
				pov_character: gPovCharacter || null,
				dual_characters: gDualCharacters ? gDualCharacters.split(',').map((s: string) => s.trim()).filter(Boolean) : [],
				narrative_voice: gNarrativeVoice,
				tense: gTense,
				tone: gTone ? gTone.split(',').map((s: string) => s.trim()).filter(Boolean) : [],
				scene_pacing: gScenePacing,
				response_length: gResponseLength,
				integrate_user_narrative: gIntegrateUserNarrative,
				preserve_user_details: gPreserveUserDetails,
				sensitive_themes: gSensitiveThemes ? gSensitiveThemes.split(',').map((s: string) => s.trim()).filter(Boolean) : [],
				hard_limits: gHardLimits ? gHardLimits.split(',').map((s: string) => s.trim()).filter(Boolean) : [],
			};
			await updateGuidelines(rpFolder, body as Partial<GuidelinesResponse>);
			addToast('Guidelines saved', 'success');
		} catch (e: any) {
			addToast(`Failed to save guidelines: ${e.message}`, 'error');
		} finally {
			guidelinesSaving = false;
		}
	}

	async function loadState() {
		stateLoading = true;
		try {
			stateSnapshot = await getFullState();
			characters = stateSnapshot.characters;
			scene = stateSnapshot.scene;
		} catch (e: any) {
			addToast(`Failed to load state: ${e.message}`, 'error');
		} finally {
			stateLoading = false;
		}
	}

	function startEditChar(name: string) {
		const c = characters[name];
		editingChar = name;
		editCharLocation = c.location ?? '';
		editCharEmotional = c.emotional_state ?? '';
	}

	function cancelEditChar() {
		editingChar = null;
	}

	async function saveChar() {
		if (!editingChar) return;
		charSaving = true;
		try {
			const updated = await updateCharacter(editingChar, {
				location: editCharLocation || undefined,
				emotional_state: editCharEmotional || undefined,
			});
			characters[editingChar] = updated;
			characters = characters;
			editingChar = null;
			addToast('Character updated', 'success');
		} catch (e: any) {
			addToast(`Failed to update character: ${e.message}`, 'error');
		} finally {
			charSaving = false;
		}
	}

	let sceneLocation = '';
	let sceneTimeOfDay = '';
	let sceneMood = '';
	let sceneTimestamp = '';
	let sceneEditing = false;

	function startEditScene() {
		sceneLocation = scene.location ?? '';
		sceneTimeOfDay = scene.time_of_day ?? '';
		sceneMood = scene.mood ?? '';
		sceneTimestamp = scene.in_story_timestamp ?? '';
		sceneEditing = true;
	}

	function cancelEditScene() {
		sceneEditing = false;
	}

	async function saveScene() {
		sceneSaving = true;
		try {
			const updated = await updateScene({
				location: sceneLocation || undefined,
				time_of_day: sceneTimeOfDay || undefined,
				mood: sceneMood || undefined,
				in_story_timestamp: sceneTimestamp || undefined,
			});
			scene = updated;
			sceneEditing = false;
			addToast('Scene updated', 'success');
		} catch (e: any) {
			addToast(`Failed to update scene: ${e.message}`, 'error');
		} finally {
			sceneSaving = false;
		}
	}

	async function loadCustomState() {
		customStateLoading = true;
		try {
			const branch = get(activeBranch) || 'main';
			const [snap, presetList] = await Promise.all([
				getCustomStateSnapshot(rpFolder, branch),
				listPresets(),
			]);
			customState = snap;
			presets = presetList;
		} catch (e: any) {
			addToast(`Failed to load custom state: ${e.message}`, 'error');
		} finally {
			customStateLoading = false;
		}
	}

	async function handleApplyPreset() {
		if (!selectedPreset) return;
		applyingPreset = true;
		try {
			await applyPreset(selectedPreset, rpFolder);
			addToast(`Preset "${selectedPreset}" applied`, 'success');
			await loadCustomState();
		} catch (e: any) {
			addToast(`Failed to apply preset: ${e.message}`, 'error');
		} finally {
			applyingPreset = false;
		}
	}

	function startEditValue(schemaId: string, entityId: string | null, currentValue: unknown) {
		editingValue = { schemaId, entityId };
		editValueStr = currentValue != null ? (typeof currentValue === 'object' ? JSON.stringify(currentValue) : String(currentValue)) : '';
	}

	function cancelEditValue() {
		editingValue = null;
	}

	async function saveValue() {
		if (!editingValue) return;
		valueSaving = true;
		try {
			const branch = get(activeBranch) || 'main';
			let parsedValue: unknown = editValueStr;
			try { parsedValue = JSON.parse(editValueStr); } catch { /* use as string */ }
			await setCustomStateValue(editingValue.schemaId, {
				rp_folder: rpFolder,
				branch,
				entity_id: editingValue.entityId ?? undefined,
				value: parsedValue,
			});
			editingValue = null;
			addToast('Value updated', 'success');
			await loadCustomState();
		} catch (e: any) {
			addToast(`Failed to save value: ${e.message}`, 'error');
		} finally {
			valueSaving = false;
		}
	}

	function getValueForSchema(schemaId: string, entityId: string | null = null): unknown {
		if (!customState) return null;
		const match = customState.values.find(
			(v) => v.schema_id === schemaId && v.entity_id === entityId,
		);
		return match?.value ?? null;
	}

	const inputClass = 'w-full bg-surface2 border border-border-custom rounded-md px-3 py-2 text-sm text-text focus:outline-none focus:ring-1 focus:ring-accent';
	const selectClass = inputClass;
</script>

<div class="flex gap-4">
	<!-- Left nav -->
	<nav class="w-44 shrink-0 bg-surface rounded-lg border border-border-custom overflow-hidden self-start">
		<div class="px-3 py-2.5 border-b border-border-custom">
			<span class="text-xs font-semibold text-text-dim uppercase tracking-wider">RP Settings</span>
		</div>
		<div class="p-1.5 space-y-0.5">
			{#each sections as section}
				<button
					class="w-full flex items-center px-3 py-2 rounded-md text-sm text-left transition-colors
						{activeSection === section.id
							? 'bg-accent/20 text-accent'
							: 'text-text-dim hover:text-text hover:bg-surface2'}"
					on:click={() => (activeSection = section.id)}
				>
					{section.label}
				</button>
			{/each}
		</div>
	</nav>

	<!-- Content -->
	<div class="flex-1 min-w-0 max-w-2xl">

		<!-- Guidelines -->
		{#if activeSection === 'guidelines'}
			<div class="bg-surface rounded-lg border border-border-custom overflow-hidden">
				<div class="px-4 py-3 border-b border-border-custom">
					<h2 class="text-sm font-semibold text-text">Story Guidelines</h2>
					<p class="text-xs text-text-dim mt-0.5">Narrative style and content rules for this RP.</p>
				</div>
				{#if guidelinesLoading}
					<div class="p-4 text-sm text-text-dim">Loading...</div>
				{:else}
					<div class="p-4 space-y-4">
						<div class="grid grid-cols-2 gap-4">
							<div>
								<label class="block text-xs font-medium text-text-dim mb-1" for="g-pov-mode">POV Mode</label>
								<select id="g-pov-mode" bind:value={gPovMode} class={selectClass}>
									<option value="single">Single</option>
									<option value="dual">Dual</option>
								</select>
							</div>
							<div>
								<label class="block text-xs font-medium text-text-dim mb-1" for="g-pov-char">POV Character</label>
								<input id="g-pov-char" type="text" bind:value={gPovCharacter} class={inputClass} />
							</div>
						</div>
						<div>
							<label class="block text-xs font-medium text-text-dim mb-1" for="g-dual-chars">Dual Characters</label>
							<input id="g-dual-chars" type="text" bind:value={gDualCharacters} placeholder="Name1, Name2" class={inputClass} />
							<p class="text-xs text-text-dim mt-0.5">Comma-separated names</p>
						</div>
						<div class="grid grid-cols-3 gap-4">
							<div>
								<label class="block text-xs font-medium text-text-dim mb-1" for="g-voice">Narrative Voice</label>
								<select id="g-voice" bind:value={gNarrativeVoice} class={selectClass}>
									<option value="first">First person</option>
									<option value="third">Third person</option>
								</select>
							</div>
							<div>
								<label class="block text-xs font-medium text-text-dim mb-1" for="g-tense">Tense</label>
								<select id="g-tense" bind:value={gTense} class={selectClass}>
									<option value="present">Present</option>
									<option value="past">Past</option>
								</select>
							</div>
							<div>
								<label class="block text-xs font-medium text-text-dim mb-1" for="g-pacing">Scene Pacing</label>
								<select id="g-pacing" bind:value={gScenePacing} class={selectClass}>
									<option value="slow">Slow</option>
									<option value="moderate">Moderate</option>
									<option value="fast">Fast</option>
								</select>
							</div>
						</div>
						<div class="grid grid-cols-2 gap-4">
							<div>
								<label class="block text-xs font-medium text-text-dim mb-1" for="g-length">Response Length</label>
								<select id="g-length" bind:value={gResponseLength} class={selectClass}>
									<option value="short">Short</option>
									<option value="medium">Medium</option>
									<option value="long">Long</option>
								</select>
							</div>
							<div>
								<label class="block text-xs font-medium text-text-dim mb-1" for="g-tone">Tone</label>
								<input id="g-tone" type="text" bind:value={gTone} placeholder="dark, gritty, atmospheric" class={inputClass} />
								<p class="text-xs text-text-dim mt-0.5">Comma-separated</p>
							</div>
						</div>
						<div class="flex items-center gap-6">
							{@render toggleField('Integrate User Narrative', gIntegrateUserNarrative, (v) => gIntegrateUserNarrative = v)}
							{@render toggleField('Preserve User Details', gPreserveUserDetails, (v) => gPreserveUserDetails = v)}
						</div>
						<div>
							<label class="block text-xs font-medium text-text-dim mb-1" for="g-themes">Sensitive Themes</label>
							<input id="g-themes" type="text" bind:value={gSensitiveThemes} placeholder="violence, substance_abuse" class={inputClass} />
							<p class="text-xs text-text-dim mt-0.5">Comma-separated</p>
						</div>
						<div>
							<label class="block text-xs font-medium text-text-dim mb-1" for="g-limits">Hard Limits</label>
							<input id="g-limits" type="text" bind:value={gHardLimits} placeholder="none" class={inputClass} />
							<p class="text-xs text-text-dim mt-0.5">Comma-separated</p>
						</div>
						<div class="flex items-center justify-end gap-3 pt-2 border-t border-border-custom">
							<button
								on:click={saveGuidelines}
								disabled={guidelinesSaving}
								class="bg-accent text-white text-sm font-medium py-1.5 px-4 rounded-md
									hover:bg-accent/90 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
							>
								{guidelinesSaving ? 'Saving...' : 'Save'}
							</button>
						</div>
					</div>
				{/if}
			</div>

		<!-- Characters -->
		{:else if activeSection === 'characters'}
			<div class="bg-surface rounded-lg border border-border-custom overflow-hidden">
				<div class="px-4 py-3 border-b border-border-custom flex items-center justify-between">
					<div>
						<h2 class="text-sm font-semibold text-text">Characters</h2>
						<p class="text-xs text-text-dim mt-0.5">All characters in the current RP state.</p>
					</div>
					<button
						on:click={loadState}
						disabled={stateLoading}
						class="text-xs text-accent hover:text-accent/80 transition-colors disabled:opacity-50"
					>
						{stateLoading ? 'Loading...' : 'Refresh'}
					</button>
				</div>
				{#if stateLoading}
					<div class="p-4 text-sm text-text-dim">Loading...</div>
				{:else if Object.keys(characters).length === 0}
					<div class="p-4 text-sm text-text-dim">No characters found.</div>
				{:else}
					<div class="divide-y divide-border-custom">
						{#each Object.entries(characters) as [name, char]}
							<div class="px-4 py-3">
								{#if editingChar === name}
									<div class="space-y-2">
										<p class="text-sm font-medium text-text">{name}</p>
										<div class="grid grid-cols-2 gap-3">
											<div>
												<label class="block text-xs text-text-dim mb-0.5" for="edit-loc-{name}">Location</label>
												<input id="edit-loc-{name}" type="text" bind:value={editCharLocation} class={inputClass} />
											</div>
											<div>
												<label class="block text-xs text-text-dim mb-0.5" for="edit-emo-{name}">Emotional State</label>
												<input id="edit-emo-{name}" type="text" bind:value={editCharEmotional} class={inputClass} />
											</div>
										</div>
										<div class="flex gap-2 justify-end">
											<button on:click={cancelEditChar} class="text-xs text-text-dim hover:text-text px-2 py-1">Cancel</button>
											<button
												on:click={saveChar}
												disabled={charSaving}
												class="bg-accent text-white text-xs font-medium py-1 px-3 rounded-md hover:bg-accent/90 disabled:opacity-50"
											>
												{charSaving ? 'Saving...' : 'Save'}
											</button>
										</div>
									</div>
								{:else}
									<div class="flex items-start justify-between">
										<div class="space-y-0.5">
											<p class="text-sm font-medium text-text">{name}</p>
											<div class="flex flex-wrap gap-x-4 gap-y-0.5 text-xs text-text-dim">
												{#if char.importance}
													<span>Importance: <span class="text-text">{char.importance}</span></span>
												{/if}
												{#if char.location}
													<span>Location: <span class="text-text">{char.location}</span></span>
												{/if}
												{#if char.emotional_state}
													<span>Emotional: <span class="text-text">{char.emotional_state}</span></span>
												{/if}
												{#if char.conditions?.length}
													<span>Conditions: <span class="text-text">{char.conditions.join(', ')}</span></span>
												{/if}
												{#if char.last_seen}
													<span>Last seen: <span class="text-text">{char.last_seen}</span></span>
												{/if}
											</div>
										</div>
										<button
											on:click={() => startEditChar(name)}
											class="text-xs text-accent hover:text-accent/80 shrink-0 ml-2"
										>
											Edit
										</button>
									</div>
								{/if}
							</div>
						{/each}
					</div>
				{/if}
			</div>

		<!-- Scene State -->
		{:else if activeSection === 'scene'}
			<div class="bg-surface rounded-lg border border-border-custom overflow-hidden">
				<div class="px-4 py-3 border-b border-border-custom flex items-center justify-between">
					<div>
						<h2 class="text-sm font-semibold text-text">Scene State</h2>
						<p class="text-xs text-text-dim mt-0.5">Current scene context.</p>
					</div>
					{#if !sceneEditing}
						<button
							on:click={startEditScene}
							class="text-xs text-accent hover:text-accent/80 transition-colors"
						>
							Edit
						</button>
					{/if}
				</div>
				{#if stateLoading}
					<div class="p-4 text-sm text-text-dim">Loading...</div>
				{:else if sceneEditing}
					<div class="p-4 space-y-4">
						<div class="grid grid-cols-2 gap-4">
							<div>
								<label class="block text-xs font-medium text-text-dim mb-1" for="s-location">Location</label>
								<input id="s-location" type="text" bind:value={sceneLocation} class={inputClass} />
							</div>
							<div>
								<label class="block text-xs font-medium text-text-dim mb-1" for="s-tod">Time of Day</label>
								<input id="s-tod" type="text" bind:value={sceneTimeOfDay} class={inputClass} />
							</div>
							<div>
								<label class="block text-xs font-medium text-text-dim mb-1" for="s-mood">Mood</label>
								<input id="s-mood" type="text" bind:value={sceneMood} class={inputClass} />
							</div>
							<div>
								<label class="block text-xs font-medium text-text-dim mb-1" for="s-ts">In-Story Timestamp</label>
								<input id="s-ts" type="text" bind:value={sceneTimestamp} class={inputClass} />
							</div>
						</div>
						<div class="flex items-center justify-end gap-2 pt-2 border-t border-border-custom">
							<button on:click={cancelEditScene} class="text-xs text-text-dim hover:text-text px-2 py-1">Cancel</button>
							<button
								on:click={saveScene}
								disabled={sceneSaving}
								class="bg-accent text-white text-sm font-medium py-1.5 px-4 rounded-md hover:bg-accent/90 disabled:opacity-50 disabled:cursor-not-allowed"
							>
								{sceneSaving ? 'Saving...' : 'Save'}
							</button>
						</div>
					</div>
				{:else}
					<div class="p-4 space-y-2">
						{@render sceneRow('Location', scene.location)}
						{@render sceneRow('Time of Day', scene.time_of_day)}
						{@render sceneRow('Mood', scene.mood)}
						{@render sceneRow('In-Story Timestamp', scene.in_story_timestamp)}
					</div>
				{/if}
			</div>

		<!-- Custom State -->
		{:else if activeSection === 'customstate'}
			<div class="space-y-4">
				<!-- Presets -->
				{#if presets.length > 0}
					<div class="bg-surface rounded-lg border border-border-custom overflow-hidden">
						<div class="px-4 py-3 border-b border-border-custom">
							<h2 class="text-sm font-semibold text-text">Presets</h2>
							<p class="text-xs text-text-dim mt-0.5">Bootstrap common custom state schemas.</p>
						</div>
						<div class="p-4 flex items-end gap-3">
							<div class="flex-1">
								<label class="block text-xs font-medium text-text-dim mb-1" for="cs-preset">Preset</label>
								<select id="cs-preset" bind:value={selectedPreset} class={selectClass}>
									<option value="">Select a preset...</option>
									{#each presets as preset}
										<option value={preset.name}>{preset.name}{preset.description ? ` — ${preset.description}` : ''} ({preset.schema_count} schemas)</option>
									{/each}
								</select>
							</div>
							<button
								on:click={handleApplyPreset}
								disabled={!selectedPreset || applyingPreset}
								class="bg-accent text-white text-xs font-medium py-2 px-3 rounded-md
									hover:bg-accent/90 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
							>
								{applyingPreset ? 'Applying...' : 'Apply'}
							</button>
						</div>
					</div>
				{/if}

				<!-- Schemas + Values -->
				<div class="bg-surface rounded-lg border border-border-custom overflow-hidden">
					<div class="px-4 py-3 border-b border-border-custom flex items-center justify-between">
						<div>
							<h2 class="text-sm font-semibold text-text">Custom State</h2>
							<p class="text-xs text-text-dim mt-0.5">Custom tracked fields and their current values.</p>
						</div>
						<button
							on:click={loadCustomState}
							disabled={customStateLoading}
							class="text-xs text-accent hover:text-accent/80 transition-colors disabled:opacity-50"
						>
							{customStateLoading ? 'Loading...' : 'Refresh'}
						</button>
					</div>
					{#if customStateLoading}
						<div class="p-4 text-sm text-text-dim">Loading...</div>
					{:else if !customState || customState.schemas.length === 0}
						<div class="p-4 text-sm text-text-dim">No custom state schemas defined. Use a preset above to get started.</div>
					{:else}
						<div class="divide-y divide-border-custom">
							{#each customState.schemas as schema}
								{@const value = getValueForSchema(schema.id)}
								<div class="px-4 py-3">
									{#if editingValue?.schemaId === schema.id && editingValue?.entityId === null}
										<div class="space-y-2">
											<div class="flex items-center gap-2">
												<p class="text-sm font-medium text-text">{schema.name}</p>
												<span class="px-1.5 py-0.5 bg-surface2 rounded text-xs text-text-dim">{schema.data_type}</span>
											</div>
											<input type="text" bind:value={editValueStr} class={inputClass} />
											<div class="flex gap-2 justify-end">
												<button on:click={cancelEditValue} class="text-xs text-text-dim hover:text-text px-2 py-1">Cancel</button>
												<button
													on:click={saveValue}
													disabled={valueSaving}
													class="bg-accent text-white text-xs font-medium py-1 px-3 rounded-md hover:bg-accent/90 disabled:opacity-50"
												>
													{valueSaving ? 'Saving...' : 'Save'}
												</button>
											</div>
										</div>
									{:else}
										<div class="flex items-center justify-between">
											<div class="space-y-0.5">
												<div class="flex items-center gap-2">
													<p class="text-sm font-medium text-text">{schema.name}</p>
													<span class="px-1.5 py-0.5 bg-surface2 rounded text-xs text-text-dim">{schema.data_type}</span>
													<span class="px-1.5 py-0.5 bg-surface2 rounded text-xs text-text-dim">{schema.category}</span>
												</div>
												<p class="text-xs text-text-dim">
													Value: <span class="text-text font-mono">{value != null ? (typeof value === 'object' ? JSON.stringify(value) : String(value)) : '(not set)'}</span>
												</p>
											</div>
											<button
												on:click={() => startEditValue(schema.id, null, value)}
												class="text-xs text-accent hover:text-accent/80 shrink-0 ml-2"
											>
												Edit
											</button>
										</div>
									{/if}
								</div>
							{/each}
						</div>
					{/if}
				</div>
			</div>
		{/if}
	</div>
</div>

{#snippet toggleField(label: string, value: boolean, onChange: (v: boolean) => void)}
	<div class="flex items-center gap-2">
		<button
			on:click={() => onChange(!value)}
			class="relative inline-flex h-5 w-9 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200
				{value ? 'bg-accent' : 'bg-surface2'}"
			role="switch"
			aria-checked={value}
			aria-label="Toggle {label}"
		>
			<span
				class="pointer-events-none inline-block h-4 w-4 rounded-full bg-white shadow transform transition duration-200
					{value ? 'translate-x-4' : 'translate-x-0'}"
			></span>
		</button>
		<span class="text-xs text-text-dim">{label}</span>
	</div>
{/snippet}

{#snippet sceneRow(label: string, value: string | null)}
	<div class="flex items-baseline justify-between py-1">
		<span class="text-xs font-medium text-text-dim">{label}</span>
		<span class="text-sm text-text">{value ?? '—'}</span>
	</div>
{/snippet}
