<script lang="ts">
	import { onMount } from 'svelte';
	import { page } from '$app/stores';
	import { listCards, getCard, reindex, auditCards, getConnections } from '$lib/api/cards';
	import { getFullState } from '$lib/api/state';
	import { listNPCs, getTrustInfo } from '$lib/api/npc';
	import { addToast } from '$lib/stores/ui';
	import { CARD_TYPES } from '$lib/types/enums';
	import type { StoryCardSummary, StoryCardDetail, CardListResponse, AuditResponse, AuditGap, GraphData, GraphNode, GraphEdge } from '$lib/types';
	import type { StateSnapshot, CharacterDetail, RelationshipDetail, EventDetail } from '$lib/types';
	import type { NPCListItem, TrustInfo } from '$lib/types';
	import ForceGraph from '$lib/components/ForceGraph.svelte';
	import { cardTypeColor, importanceColor, trustStageColor, significanceColor } from '$lib/utils/colors';
	import { barStyle, formatDate } from '$lib/utils/format';

	// ── Tool nav ──
	type ToolId = 'library' | 'state' | 'trust' | 'graph';
	const tools: { id: ToolId; icon: string; label: string }[] = [
		{ id: 'library', icon: '📚', label: 'Library' },
		{ id: 'state',   icon: '🎭', label: 'State' },
		{ id: 'trust',   icon: '🤝', label: 'Trust' },
		{ id: 'graph',   icon: '🔗', label: 'Graph' },
	];
	let activeTool: ToolId = 'library';
	let loadedTools = new Set<string>();

	// ── Stats bar ──
	let cardCount = 0;
	let connectionCount = 0;
	let orphanCount = 0;
	let reindexing = false;

	// ── Library tool ──
	let cards: StoryCardSummary[] = [];
	let librarySearch = '';
	let libraryTypeFilter = '';
	let selectedCard: StoryCardDetail | null = null;
	let loadingCard = false;
	let libraryTab: 'detail' | 'gaps' = 'detail';
	let auditResult: AuditResponse | null = null;
	let auditing = false;

	// ── State tool ──
	let stateSnapshot: StateSnapshot | null = null;
	let stateTab: 'scene' | 'characters' | 'events' = 'scene';
	let showAllEvents = false;

	// ── Trust tool ──
	let npcs: NPCListItem[] = [];
	let trustLoading = false;
	let expandedNpc: string | null = null;
	let trustDetails: Record<string, TrustInfo> = {};
	let loadingTrust: Record<string, boolean> = {};
	let trustSortBy: 'trust_desc' | 'trust_asc' | 'name' | 'importance' = 'trust_desc';
	let trustFilter = '';

	// ── Graph tool ──
	let graphData: GraphData | null = null;
	let graphFilter = '';
	let graphHiddenTypes = new Set<string>();
	let graphFiltersOpen = true;
	let graphSelectedNode: GraphNode | null = null;
	let graphSelectedCard: StoryCardDetail | null = null;
	let loadingGraphCard = false;

	$: graphFilteredData = graphData && graphHiddenTypes.size > 0
		? {
			nodes: graphData.nodes.filter(n => !graphHiddenTypes.has(n.card_type)),
			edges: graphData.edges.filter(e => {
				const nodeNames = new Set(graphData!.nodes.filter(n => !graphHiddenTypes.has(n.card_type)).map(n => n.name));
				return nodeNames.has(e.from) && nodeNames.has(e.to);
			}),
		}
		: graphData;

	function toggleGraphType(type: string) {
		if (graphHiddenTypes.has(type)) {
			graphHiddenTypes.delete(type);
		} else {
			graphHiddenTypes.add(type);
		}
		graphHiddenTypes = new Set(graphHiddenTypes); // trigger reactivity
	}

	async function handleGraphNodeClick(node: GraphNode) {
		graphSelectedNode = node;
		loadingGraphCard = true;
		try {
			graphSelectedCard = await getCard(node.card_type, node.name);
		} catch {
			graphSelectedCard = null;
		} finally {
			loadingGraphCard = false;
		}
	}

	// ── Deep-link support ──
	let pendingExpandNpc: string | null = null;

	// ── Init ──
	onMount(async () => {
		// Check for deep-link query params
		const toolParam = $page.url.searchParams.get('tool');
		const npcParam = $page.url.searchParams.get('npc');
		if (npcParam) pendingExpandNpc = npcParam;

		await loadStats();

		if (toolParam && tools.some(t => t.id === toolParam)) {
			await switchTool(toolParam as ToolId);
		} else {
			await loadTool('library');
		}

		// Auto-expand NPC after trust tool loads
		if (pendingExpandNpc && toolParam === 'trust') {
			await toggleExpand(pendingExpandNpc);
			pendingExpandNpc = null;
		}
	});

	async function loadStats() {
		try {
			const res: CardListResponse = await listCards();
			cards = res.cards;
			cardCount = res.total;
			connectionCount = Math.floor(cards.reduce((sum, c) => sum + c.connection_count, 0) / 2);
			orphanCount = cards.filter(c => c.connection_count === 0).length;
		} catch (e: any) {
			addToast(e.message ?? 'Failed to load cards', 'error');
		}
	}

	async function loadTool(tool: ToolId) {
		if (loadedTools.has(tool)) return;
		try {
			if (tool === 'library') {
				// cards already loaded in loadStats
			} else if (tool === 'state') {
				stateSnapshot = await getFullState();
			} else if (tool === 'trust') {
				trustLoading = true;
				npcs = await listNPCs();
				trustLoading = false;
			} else if (tool === 'graph') {
				graphData = await getConnections();
			}
			loadedTools.add(tool);
			loadedTools = loadedTools; // trigger reactivity
		} catch (e: any) {
			addToast(e.message ?? `Failed to load ${tool}`, 'error');
			if (tool === 'trust') trustLoading = false;
		}
	}

	function switchTool(tool: ToolId) {
		activeTool = tool;
		loadTool(tool);
	}

	async function handleReindex() {
		reindexing = true;
		try {
			const res = await reindex();
			addToast(`Reindexed: ${res.entities} entities, ${res.connections} connections (${res.duration_ms}ms)`, 'success');
			// Reset loaded tools so they refetch
			loadedTools = new Set<string>();
			await loadStats();
			await loadTool(activeTool);
		} catch (e: any) {
			addToast(e.message ?? 'Reindex failed', 'error');
		} finally {
			reindexing = false;
		}
	}

	// ── Library helpers ──
	async function selectCard(card: StoryCardSummary) {
		loadingCard = true;
		libraryTab = 'detail';
		try {
			selectedCard = await getCard(card.card_type, card.name);
		} catch (e: any) {
			addToast(e.message ?? 'Failed to load card', 'error');
		} finally {
			loadingCard = false;
		}
	}

	async function selectCardByName(name: string) {
		const match = cards.find(c => c.name === name);
		if (match) await selectCard(match);
	}

	async function runAudit() {
		auditing = true;
		try {
			auditResult = await auditCards('quick');
		} catch (e: any) {
			addToast(e.message ?? 'Audit failed', 'error');
		} finally {
			auditing = false;
		}
	}

	$: filteredCards = cards
		.filter(c => {
			if (libraryTypeFilter && c.card_type !== libraryTypeFilter) return false;
			if (librarySearch.trim()) {
				const q = librarySearch.toLowerCase();
				return c.name.toLowerCase().includes(q) || c.card_type.toLowerCase().includes(q) ||
					(c.summary ?? '').toLowerCase().includes(q);
			}
			return true;
		})
		.sort((a, b) => b.connection_count - a.connection_count || a.name.localeCompare(b.name));

	// ── State helpers ──
	$: playerChars = stateSnapshot
		? Object.entries(stateSnapshot.characters).filter(([, c]) => c.is_player_character)
		: [];
	$: npcChars = stateSnapshot
		? Object.entries(stateSnapshot.characters).filter(([, c]) => !c.is_player_character)
		: [];
	$: sortedEvents = stateSnapshot
		? [...stateSnapshot.events].sort((a, b) => b.id - a.id)
		: [];
	$: visibleEvents = showAllEvents ? sortedEvents : sortedEvents.slice(0, 50);

	// ── Trust helpers ──
	async function toggleExpand(name: string) {
		if (expandedNpc === name) { expandedNpc = null; return; }
		expandedNpc = name;
		if (!trustDetails[name]) {
			loadingTrust[name] = true;
			try {
				trustDetails[name] = await getTrustInfo(name);
				trustDetails = { ...trustDetails };
			} catch (e: any) {
				addToast(e.message ?? `Failed to load trust for ${name}`, 'error');
			} finally {
				loadingTrust[name] = false;
			}
		}
	}


	$: sortedTrustNpcs = [...npcs]
		.filter(n =>
			!trustFilter.trim() ||
			n.name.toLowerCase().includes(trustFilter.toLowerCase()) ||
			(n.primary_archetype ?? '').toLowerCase().includes(trustFilter.toLowerCase())
		)
		.sort((a, b) => {
			if (trustSortBy === 'trust_desc') return b.trust_score - a.trust_score;
			if (trustSortBy === 'trust_asc')  return a.trust_score - b.trust_score;
			if (trustSortBy === 'name')        return a.name.localeCompare(b.name);
			if (trustSortBy === 'importance') {
				const rank = (i: string | null) => i === 'primary' ? 0 : i === 'secondary' ? 1 : 2;
				return rank(a.importance) - rank(b.importance);
			}
			return 0;
		});

</script>

<!-- Stats bar -->
<div class="flex items-center justify-between bg-surface border border-border-custom rounded-lg px-4 py-2 mb-4">
	<div class="flex items-center gap-4 text-sm">
		<span class="text-text">{cardCount} <span class="text-text-dim">cards</span></span>
		<span class="text-text-dim">·</span>
		<span class="text-text">{connectionCount} <span class="text-text-dim">connections</span></span>
		<span class="text-text-dim">·</span>
		<span class="{orphanCount > 0 ? 'text-warning' : 'text-text'}">{orphanCount} <span class="text-text-dim">orphans</span></span>
	</div>
	<button
		class="px-3 py-1 text-xs rounded bg-surface2 text-text-dim hover:text-text hover:bg-surface2/80 transition-colors disabled:opacity-50"
		on:click={handleReindex}
		disabled={reindexing}
	>
		{reindexing ? 'Reindexing...' : 'Reindex'}
	</button>
</div>

<!-- Main layout: nav + content -->
<div class="flex gap-2">
	<!-- Tool nav -->
	<nav class="w-40 shrink-0 bg-surface rounded border border-border-custom overflow-hidden self-start">
		<div class="px-2 py-1.5 border-b border-border-custom">
			<span class="text-xs font-semibold text-text-dim uppercase tracking-wider">Dashboard</span>
		</div>
		<div class="p-1 space-y-0.5">
			{#each tools as tool}
				<button
					class="w-full flex items-center gap-2 px-2 py-1.5 rounded text-xs text-left transition-colors
						{activeTool === tool.id
							? 'bg-accent/20 text-accent'
							: 'text-text-dim hover:text-text hover:bg-surface2'}"
					on:click={() => switchTool(tool.id)}
				>
					<span class="leading-none">{tool.icon}</span>
					<span>{tool.label}</span>
				</button>
			{/each}
		</div>
	</nav>

	<!-- Tool content -->
	<div class="flex-1 min-w-0">

		<!-- ═══════════ LIBRARY ═══════════ -->
		{#if activeTool === 'library'}
			{#if selectedCard}
				<!-- Detail view (replaces grid when a card is selected) -->
				<div class="bg-surface border border-border-custom rounded-lg overflow-hidden">
					<div class="flex items-center gap-2 px-4 py-2.5 border-b border-border-custom">
						<button
							class="flex items-center gap-1.5 text-sm text-text-dim hover:text-text transition-colors"
							on:click={() => (selectedCard = null)}
						>
							<svg class="w-4 h-4" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="2">
								<path d="M10 4L6 8l4 4" />
							</svg>
							Back to library
						</button>
					</div>
					<div class="p-4 space-y-4">
						<!-- Header -->
						<div class="flex items-center gap-2">
							<span class="px-1.5 py-0.5 rounded text-xs {cardTypeColor(selectedCard.card_type)}">{selectedCard.card_type}</span>
							<h3 class="text-base font-semibold text-text">{selectedCard.name}</h3>
							{#if selectedCard.importance}
								<span class="px-1.5 py-0.5 rounded text-xs {importanceColor(selectedCard.importance)}">{selectedCard.importance}</span>
							{/if}
						</div>

						<!-- Content summary -->
						{#if selectedCard.content}
							<div class="text-sm text-text-dim leading-relaxed whitespace-pre-wrap max-h-60 overflow-y-auto">
								{selectedCard.content.slice(0, 800)}{selectedCard.content.length > 800 ? '...' : ''}
							</div>
						{/if}

						<!-- Frontmatter -->
						{#if Object.keys(selectedCard.frontmatter).length > 0}
							<div>
								<p class="text-xs text-text-dim uppercase tracking-wider mb-2">Frontmatter</p>
								<div class="grid grid-cols-2 gap-x-4 gap-y-1">
									{#each Object.entries(selectedCard.frontmatter) as [key, val]}
										<div class="flex gap-2 text-xs py-0.5">
											<span class="text-text-dim shrink-0">{key}</span>
											<span class="text-text truncate">{typeof val === 'object' ? JSON.stringify(val) : String(val)}</span>
										</div>
									{/each}
								</div>
							</div>
						{/if}

						<!-- Connections -->
						{#if selectedCard.connections.length > 0}
							<div>
								<p class="text-xs text-text-dim uppercase tracking-wider mb-2">Connections ({selectedCard.connections.length})</p>
								<div class="flex flex-wrap gap-1.5">
									{#each selectedCard.connections as conn}
										<button
											class="flex items-center gap-1 text-xs bg-surface2 hover:bg-accent/10 rounded-lg px-2.5 py-1.5 transition-colors"
											on:click={() => selectCardByName(conn.to_entity)}
										>
											<span class="text-text-dim text-[10px]">{conn.connection_type}</span>
											<span class="text-accent">{conn.to_entity}</span>
										</button>
									{/each}
								</div>
							</div>
						{:else}
							<p class="text-xs text-warning">No connections (orphan card)</p>
						{/if}
					</div>
				</div>
			{:else}
				<!-- Grid view -->
				<div class="space-y-3">
					<!-- Filter controls -->
					<div class="flex items-center gap-2">
						<input
							type="text"
							bind:value={librarySearch}
							placeholder="Search cards..."
							class="flex-1 bg-surface border border-border-custom rounded-lg px-3 py-2 text-sm text-text
								placeholder:text-text-dim/50 focus:outline-none focus:ring-1 focus:ring-accent"
						/>
						<select
							bind:value={libraryTypeFilter}
							class="bg-surface border border-border-custom rounded-lg px-3 py-2 text-sm text-text
								focus:outline-none focus:ring-1 focus:ring-accent"
						>
							<option value="">All types</option>
							{#each CARD_TYPES as ct}
								<option value={ct}>{ct}</option>
							{/each}
						</select>
						<button
							class="px-3 py-2 text-xs rounded-lg bg-accent/20 text-accent hover:bg-accent/30 transition-colors disabled:opacity-50"
							on:click={runAudit}
							disabled={auditing}
						>
							{auditing ? 'Auditing...' : 'Run Audit'}
						</button>
						<span class="text-xs text-text-dim shrink-0">{filteredCards.length} / {cards.length}</span>
					</div>

					<!-- Audit results (inline if available) -->
					{#if auditResult && auditResult.gaps.length > 0}
						<div class="bg-warning/5 border border-warning/20 rounded-lg px-4 py-3">
							<p class="text-xs font-semibold text-warning mb-2">
								{auditResult.total_gaps} gap{auditResult.total_gaps !== 1 ? 's' : ''} found
								<span class="text-text-dim font-normal">({auditResult.total_exchanges_scanned} exchanges scanned)</span>
							</p>
							<div class="flex flex-wrap gap-1.5">
								{#each auditResult.gaps.slice(0, 8) as gap}
									<span class="text-xs bg-surface px-2 py-1 rounded-lg border border-border-custom">
										{gap.entity_name}
										{#if gap.suggested_type}
											<span class="text-text-dim">({gap.suggested_type})</span>
										{/if}
										<span class="text-text-dim font-mono">{gap.mention_count}x</span>
									</span>
								{/each}
								{#if auditResult.gaps.length > 8}
									<span class="text-xs text-text-dim self-center">+{auditResult.gaps.length - 8} more</span>
								{/if}
							</div>
						</div>
					{/if}

					<!-- Card grid -->
					{#if filteredCards.length === 0}
						<div class="bg-surface rounded-lg border border-border-custom p-8 text-center text-sm text-text-dim">
							No cards match your filters.
						</div>
					{:else}
						<div class="grid grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-3">
							{#each filteredCards as card}
								<button
									class="bg-surface rounded-lg border border-border-custom p-3 text-left
										hover:border-accent/40 hover:bg-surface2/50 transition-all group"
									on:click={() => selectCard(card)}
								>
									<div class="flex items-center gap-1.5 mb-2">
										<span class="px-1.5 py-0.5 rounded text-[10px] leading-none {cardTypeColor(card.card_type)}">{card.card_type}</span>
										{#if card.connection_count === 0}
											<span class="text-warning text-[10px] ml-auto" title="Orphan card">orphan</span>
										{:else}
											<span class="text-text-dim text-[10px] ml-auto">{card.connection_count} conn.</span>
										{/if}
									</div>
									<p class="text-sm font-medium text-text truncate group-hover:text-accent transition-colors">{card.name}</p>
									{#if card.summary}
										<p class="text-xs text-text-dim mt-1 line-clamp-2">{card.summary}</p>
									{/if}
								</button>
							{/each}
						</div>
					{/if}
				</div>
			{/if}

		<!-- ═══════════ STATE ═══════════ -->
		{:else if activeTool === 'state'}
			{#if !stateSnapshot}
				<div class="bg-surface border border-border-custom rounded-lg p-8 text-center text-sm text-text-dim">
					Loading state...
				</div>
			{:else}
				<div class="bg-surface border border-border-custom rounded-lg overflow-hidden">
					<!-- Sub-tabs -->
					<div class="flex border-b border-border-custom">
						<button
							class="px-3 py-1.5 text-xs transition-colors {stateTab === 'scene' ? 'bg-accent/20 text-accent border-b-2 border-accent' : 'text-text-dim hover:text-text'}"
							on:click={() => (stateTab = 'scene')}
						>Scene</button>
						<button
							class="px-3 py-1.5 text-xs transition-colors {stateTab === 'characters' ? 'bg-accent/20 text-accent border-b-2 border-accent' : 'text-text-dim hover:text-text'}"
							on:click={() => (stateTab = 'characters')}
						>Characters</button>
						<button
							class="px-3 py-1.5 text-xs transition-colors {stateTab === 'events' ? 'bg-accent/20 text-accent border-b-2 border-accent' : 'text-text-dim hover:text-text'}"
							on:click={() => (stateTab = 'events')}
						>Events</button>
					</div>

					<div class="p-3">
						<!-- Scene -->
						{#if stateTab === 'scene'}
							{@const sc = stateSnapshot.scene}
							{#if !sc.location && !sc.time_of_day && !sc.mood && !sc.in_story_timestamp}
								<div class="text-xs text-text-dim">No scene state data available.</div>
							{:else}
								<div class="grid grid-cols-2 gap-3 text-xs">
									{#each [['Location', sc.location], ['Time of Day', sc.time_of_day], ['Mood', sc.mood], ['Timestamp', sc.in_story_timestamp]] as [label, val]}
										{#if val}
											<div>
												<span class="text-text-dim text-[10px] uppercase tracking-wider">{label}</span>
												<div class="text-text mt-0.5">{val}</div>
											</div>
										{/if}
									{/each}
								</div>
							{/if}

						<!-- Characters -->
						{:else if stateTab === 'characters'}
							<div class="space-y-4">
								<!-- Player Characters -->
								{#if playerChars.length > 0}
									<div>
										<h4 class="text-xs text-text-dim uppercase tracking-wider mb-2">Player Characters</h4>
										<div class="space-y-1">
											{#each playerChars as [name, char]}
												<details class="group">
													<summary class="flex items-center gap-2 text-xs cursor-pointer hover:bg-surface2 rounded px-2 py-1.5">
														<span class="text-text font-medium">{name}</span>
														{#if char.importance}
															<span class="px-1 py-0.5 rounded text-[10px] {importanceColor(char.importance)}">{char.importance}</span>
														{/if}
														{#if char.location}
															<span class="text-text-dim">@ {char.location}</span>
														{/if}
														{#if char.emotional_state}
															<span class="text-text-dim italic">{char.emotional_state}</span>
														{/if}
													</summary>
													<div class="pl-4 pb-2 text-xs space-y-1">
														{#if char.conditions.length > 0}
															<div class="flex gap-1 flex-wrap">
																<span class="text-text-dim">Conditions:</span>
																{#each char.conditions as cond}
																	<span class="bg-surface2 px-1 py-0.5 rounded text-[10px]">{cond}</span>
																{/each}
															</div>
														{/if}
														{#if char.primary_archetype}
															<div class="text-text-dim">Archetype: <span class="text-text">{char.primary_archetype}</span></div>
														{/if}
														{#if char.behavioral_modifiers.length > 0}
															<div class="flex gap-1 flex-wrap">
																<span class="text-text-dim">Modifiers:</span>
																{#each char.behavioral_modifiers as mod}
																	<span class="bg-surface2 px-1 py-0.5 rounded text-[10px]">{mod}</span>
																{/each}
															</div>
														{/if}
														{#if char.last_seen}
															<div class="text-text-dim">Last seen: {char.last_seen}</div>
														{/if}
													</div>
												</details>
											{/each}
										</div>
									</div>
								{/if}

								<!-- NPCs -->
								{#if npcChars.length > 0}
									<div>
										<h4 class="text-xs text-text-dim uppercase tracking-wider mb-2">NPCs ({npcChars.length})</h4>
										<div class="space-y-1">
											{#each npcChars as [name, char]}
												<details class="group">
													<summary class="flex items-center gap-2 text-xs cursor-pointer hover:bg-surface2 rounded px-2 py-1.5">
														<span class="text-text font-medium">{name}</span>
														{#if char.importance}
															<span class="px-1 py-0.5 rounded text-[10px] {importanceColor(char.importance)}">{char.importance}</span>
														{/if}
														{#if char.location}
															<span class="text-text-dim">@ {char.location}</span>
														{/if}
														{#if char.emotional_state}
															<span class="text-text-dim italic">{char.emotional_state}</span>
														{/if}
													</summary>
													<div class="pl-4 pb-2 text-xs space-y-1">
														{#if char.conditions.length > 0}
															<div class="flex gap-1 flex-wrap">
																<span class="text-text-dim">Conditions:</span>
																{#each char.conditions as cond}
																	<span class="bg-surface2 px-1 py-0.5 rounded text-[10px]">{cond}</span>
																{/each}
															</div>
														{/if}
														{#if char.primary_archetype}
															<div class="text-text-dim">Archetype: <span class="text-text">{char.primary_archetype}</span>
																{#if char.secondary_archetype} / {char.secondary_archetype}{/if}
															</div>
														{/if}
														{#if char.behavioral_modifiers.length > 0}
															<div class="flex gap-1 flex-wrap">
																<span class="text-text-dim">Modifiers:</span>
																{#each char.behavioral_modifiers as mod}
																	<span class="bg-surface2 px-1 py-0.5 rounded text-[10px]">{mod}</span>
																{/each}
															</div>
														{/if}
														{#if char.last_seen}
															<div class="text-text-dim">Last seen: {char.last_seen}</div>
														{/if}
													</div>
												</details>
											{/each}
										</div>
									</div>
								{/if}

								<!-- Relationships summary -->
								{#if stateSnapshot.relationships.length > 0}
									<div>
										<h4 class="text-xs text-text-dim uppercase tracking-wider mb-2">Relationships</h4>
										<div class="overflow-x-auto">
											<table class="w-full text-xs">
												<thead>
													<tr class="text-text-dim text-left border-b border-border-custom">
														<th class="pb-1 pr-3">Character A</th>
														<th class="pb-1 pr-3">Character B</th>
														<th class="pb-1 pr-3">Trust</th>
														<th class="pb-1">Stage</th>
													</tr>
												</thead>
												<tbody>
													{#each stateSnapshot.relationships as rel}
														<tr class="border-b border-border-custom/30">
															<td class="py-1 pr-3 text-text">{rel.character_a}</td>
															<td class="py-1 pr-3 text-text">{rel.character_b}</td>
															<td class="py-1 pr-3 font-mono {rel.live_trust_score > 0 ? 'text-success' : rel.live_trust_score < 0 ? 'text-error' : 'text-text-dim'}">
																{rel.live_trust_score > 0 ? '+' : ''}{rel.live_trust_score}
															</td>
															<td class="py-1">
																<span class="px-1 py-0.5 rounded text-[10px] {trustStageColor(rel.trust_stage)}">{rel.trust_stage}</span>
															</td>
														</tr>
													{/each}
												</tbody>
											</table>
										</div>
									</div>
								{/if}
							</div>

						<!-- Events -->
						{:else if stateTab === 'events'}
							{#if sortedEvents.length === 0}
								<div class="text-xs text-text-dim">No events recorded.</div>
							{:else}
								<div class="space-y-1">
									{#each visibleEvents as evt}
										<div class="flex items-start gap-2 text-xs py-1.5 border-b border-border-custom/50">
											<span class="text-text-dim shrink-0 w-20 truncate">{evt.in_story_timestamp ?? '—'}</span>
											<span class="text-text flex-1">{evt.event}</span>
											{#if evt.significance}
												<span class="px-1 py-0.5 rounded text-[10px] shrink-0 {significanceColor(evt.significance)}">{evt.significance}</span>
											{/if}
											<div class="flex gap-0.5 shrink-0">
												{#each evt.characters as ch}
													<span class="bg-surface2 px-1 py-0.5 rounded text-[10px] text-text-dim">{ch}</span>
												{/each}
											</div>
										</div>
									{/each}
									{#if !showAllEvents && sortedEvents.length > 50}
										<button
											class="text-xs text-accent hover:underline"
											on:click={() => (showAllEvents = true)}
										>Show all {sortedEvents.length} events</button>
									{/if}
								</div>
							{/if}
						{/if}
					</div>
				</div>
			{/if}

		<!-- ═══════════ TRUST ═══════════ -->
		{:else if activeTool === 'trust'}
			<div class="space-y-4">
				<!-- Controls -->
				<div class="flex items-center gap-3">
					<input
						type="text"
						bind:value={trustFilter}
						placeholder="Filter by name or archetype..."
						class="flex-1 bg-surface border border-border-custom rounded-lg px-3 py-2 text-sm text-text
							placeholder:text-text-dim/50 focus:outline-none focus:ring-1 focus:ring-accent"
					/>
					<select
						bind:value={trustSortBy}
						class="bg-surface border border-border-custom rounded-lg px-3 py-2 text-sm text-text
							focus:outline-none focus:ring-1 focus:ring-accent"
					>
						<option value="trust_desc">Trust: High → Low</option>
						<option value="trust_asc">Trust: Low → High</option>
						<option value="name">Name A-Z</option>
						<option value="importance">Importance</option>
					</select>
					<span class="text-sm text-text-dim shrink-0">{sortedTrustNpcs.length} NPC{sortedTrustNpcs.length !== 1 ? 's' : ''}</span>
				</div>

				<!-- NPC list -->
				{#if trustLoading}
					<div class="bg-surface rounded-lg border border-border-custom p-8 text-center text-sm text-text-dim">
						Loading NPCs...
					</div>
				{:else if sortedTrustNpcs.length === 0}
					<div class="bg-surface rounded-lg border border-border-custom p-8 text-center text-sm text-text-dim">
						{trustFilter ? 'No NPCs match your filter.' : 'No NPCs found for this RP.'}
					</div>
				{:else}
					<div class="space-y-2">
						{#each sortedTrustNpcs as npc}
							<div class="bg-surface rounded-lg border border-border-custom overflow-hidden">
								<!-- NPC summary row -->
								<button
									class="w-full flex items-center gap-3 px-4 py-3 hover:bg-surface2 transition-colors text-left"
									on:click={() => toggleExpand(npc.name)}
								>
									<div class="flex items-center gap-2 w-48 shrink-0 min-w-0">
										<span class="font-medium text-text truncate">{npc.name}</span>
									</div>
									<div class="flex items-center gap-1.5 shrink-0">
										{#if npc.importance}
											<span class="text-xs px-1.5 py-0.5 rounded {importanceColor(npc.importance)}">{npc.importance}</span>
										{/if}
										{#if npc.primary_archetype}
											<span class="text-xs px-1.5 py-0.5 rounded bg-surface2 text-text-dim">{npc.primary_archetype}</span>
										{/if}
									</div>
									<!-- Trust bar -->
									<div class="flex-1 flex items-center gap-3 min-w-0">
										<div class="relative flex-1 h-2 bg-surface2 rounded-full overflow-hidden">
											<div class="absolute top-0 bottom-0 w-px bg-border-custom" style="left:50%"></div>
											<div class="absolute top-0 bottom-0 rounded-full" style="{barStyle(npc.trust_score)}"></div>
										</div>
										<span class="text-sm font-mono w-10 text-right shrink-0
											{npc.trust_score > 0 ? 'text-success' : npc.trust_score < 0 ? 'text-error' : 'text-text-dim'}">
											{npc.trust_score > 0 ? '+' : ''}{npc.trust_score}
										</span>
									</div>
									{#if npc.trust_stage}
										<span class="text-xs px-2 py-0.5 rounded {trustStageColor(npc.trust_stage)} shrink-0">
											{npc.trust_stage}
										</span>
									{/if}
									<svg class="w-4 h-4 text-text-dim shrink-0 transition-transform {expandedNpc === npc.name ? 'rotate-180' : ''}"
										viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="2">
										<path d="M4 6l4 4 4-4" />
									</svg>
								</button>

								<!-- Expanded details -->
								{#if expandedNpc === npc.name}
									<div class="border-t border-border-custom">
										<div class="px-4 py-3 grid grid-cols-2 gap-4 text-sm border-b border-border-custom">
											<div class="space-y-1.5">
												{#if npc.emotional_state}
													<div><span class="text-text-dim text-xs">Emotional state</span><br>
														<span class="text-text">{npc.emotional_state}</span></div>
												{/if}
												{#if npc.location}
													<div><span class="text-text-dim text-xs">Location</span><br>
														<span class="text-text">{npc.location}</span></div>
												{/if}
												{#if npc.secondary_archetype}
													<div><span class="text-text-dim text-xs">Secondary archetype</span><br>
														<span class="text-text">{npc.secondary_archetype}</span></div>
												{/if}
											</div>
											{#if npc.behavioral_modifiers?.length}
												<div>
													<span class="text-text-dim text-xs">Behavioral modifiers</span>
													<div class="flex flex-wrap gap-1 mt-1">
														{#each npc.behavioral_modifiers as mod}
															<span class="text-xs bg-surface2 text-text-dim px-1.5 py-0.5 rounded">{mod}</span>
														{/each}
													</div>
												</div>
											{/if}
										</div>

										{#if loadingTrust[npc.name]}
											<div class="px-4 py-3 text-xs text-text-dim">Loading trust history...</div>
										{:else if trustDetails[npc.name]}
											{@const td = trustDetails[npc.name]}
											<div class="px-4 py-3 space-y-3">
												<div class="flex items-center gap-4 text-sm">
													<span class="text-text-dim text-xs">This session:</span>
													{#if td.session_gains > 0}
														<span class="text-success text-xs">+{td.session_gains} gains</span>
													{/if}
													{#if td.session_losses > 0}
														<span class="text-error text-xs">-{td.session_losses} losses</span>
													{/if}
													{#if td.session_gains === 0 && td.session_losses === 0}
														<span class="text-text-dim text-xs">No changes this session</span>
													{/if}
												</div>
												{#if td.history?.length}
													<div>
														<p class="text-xs text-text-dim mb-2">Recent history</p>
														<div class="space-y-1 max-h-48 overflow-y-auto">
															{#each td.history.slice(-20).reverse() as event}
																<div class="flex items-start gap-2 text-xs py-1 border-b border-border-custom/50 last:border-0">
																	<span class="font-mono shrink-0
																		{event.direction === 'increase' ? 'text-success' : event.direction === 'decrease' ? 'text-error' : 'text-text-dim'}">
																		{event.direction === 'increase' ? '+' : event.direction === 'decrease' ? '-' : '·'}{Math.abs(event.change)}
																	</span>
																	<span class="text-text-dim shrink-0">{formatDate(event.date)}</span>
																	{#if event.reason}
																		<span class="text-text flex-1">{event.reason}</span>
																	{/if}
																</div>
															{/each}
														</div>
													</div>
												{:else}
													<p class="text-xs text-text-dim">No trust history recorded.</p>
												{/if}
											</div>
										{/if}
									</div>
								{/if}
							</div>
						{/each}
					</div>
				{/if}
			</div>

		<!-- ═══════════ GRAPH ═══════════ -->
		{:else if activeTool === 'graph'}
			<div class="relative bg-surface border border-border-custom rounded-lg overflow-hidden flex flex-col" style="height: calc(100vh - 180px)">

				<!-- Graph canvas (full area) -->
				<div class="flex-1 min-h-0">
					{#if !graphFilteredData}
						<div class="flex items-center justify-center h-full text-xs text-text-dim">Loading graph data...</div>
					{:else}
						<ForceGraph data={graphFilteredData} filter={graphFilter} onNodeClick={handleGraphNodeClick} />
					{/if}
				</div>

				<!-- Floating filter panel (top-left) -->
				<div class="absolute top-3 left-3 z-10">
					{#if graphFiltersOpen}
						<div class="bg-surface/95 backdrop-blur-sm border border-border-custom rounded-lg shadow-lg w-64">
							<div class="flex items-center justify-between px-3 py-2 border-b border-border-custom">
								<span class="text-xs font-semibold text-text-dim uppercase tracking-wider">Filters</span>
								<button
									class="text-xs text-text-dim hover:text-text transition-colors"
									on:click={() => (graphFiltersOpen = false)}
								>Hide</button>
							</div>
							<div class="p-3 space-y-3">
								<input
									type="text"
									bind:value={graphFilter}
									placeholder="Search nodes..."
									class="w-full bg-surface2 border border-border-custom rounded px-2 py-1.5 text-xs text-text
										placeholder:text-text-dim/50 focus:outline-none focus:ring-1 focus:ring-accent"
								/>
								{#if graphData}
									<p class="text-[10px] text-text-dim">{graphData.nodes.length} nodes · {graphData.edges.length} edges</p>
									<div class="flex flex-wrap gap-1">
										{#each [['character', '#a78bfa'], ['npc', '#4ade80'], ['location', '#60a5fa'], ['secret', '#f87171'], ['organization', '#fb923c'], ['plot_thread', '#f472b6'], ['item', '#2dd4bf'], ['lore', '#818cf8']] as [type, color]}
											<button
												class="flex items-center gap-1 shrink-0 px-2 py-1 rounded-full transition-all border text-[10px]
													{graphHiddenTypes.has(type)
														? 'opacity-30 border-transparent text-text-dim'
														: 'border-border-custom/50 text-text-dim hover:text-text'}"
												on:click={() => toggleGraphType(type)}
												title="{graphHiddenTypes.has(type) ? 'Show' : 'Hide'} {type} nodes"
											>
												<span class="w-2 h-2 rounded-full" style="background:{color}"></span>
												{type}
											</button>
										{/each}
									</div>
								{/if}
							</div>
						</div>
					{:else}
						<button
							class="bg-surface/95 backdrop-blur-sm border border-border-custom rounded-lg shadow-lg px-3 py-2 text-xs text-text-dim hover:text-text transition-colors"
							on:click={() => (graphFiltersOpen = true)}
						>Filters</button>
					{/if}
				</div>

				<!-- Floating card preview (top-right, on node click) -->
				{#if graphSelectedNode}
					<div class="absolute top-3 right-3 z-10 bg-surface/95 backdrop-blur-sm border border-border-custom rounded-lg shadow-lg w-72 max-h-[60%] overflow-y-auto">
						<div class="flex items-center justify-between px-3 py-2 border-b border-border-custom">
							<div class="flex items-center gap-2 min-w-0">
								<span class="px-1.5 py-0.5 rounded text-[10px] leading-none {cardTypeColor(graphSelectedNode.card_type)}">{graphSelectedNode.card_type}</span>
								<span class="text-xs font-medium text-text truncate">{graphSelectedNode.name}</span>
							</div>
							<button
								class="text-xs text-text-dim hover:text-text transition-colors shrink-0 ml-2"
								on:click={() => { graphSelectedNode = null; graphSelectedCard = null; }}
							>Close</button>
						</div>
						<div class="p-3">
							{#if loadingGraphCard}
								<p class="text-xs text-text-dim">Loading...</p>
							{:else if graphSelectedCard}
								{#if graphSelectedCard.importance}
									<span class="text-[10px] px-1.5 py-0.5 rounded {importanceColor(graphSelectedCard.importance)}">{graphSelectedCard.importance}</span>
								{/if}
								{#if graphSelectedCard.content}
									<p class="text-xs text-text-dim mt-2 leading-relaxed whitespace-pre-wrap">{graphSelectedCard.content.slice(0, 400)}{graphSelectedCard.content.length > 400 ? '...' : ''}</p>
								{/if}
								{#if graphSelectedCard.connections.length > 0}
									<div class="mt-3">
										<p class="text-[10px] text-text-dim uppercase tracking-wider mb-1">Connections ({graphSelectedCard.connections.length})</p>
										<div class="flex flex-wrap gap-1">
											{#each graphSelectedCard.connections.slice(0, 8) as conn}
												<span class="text-[10px] bg-surface2 text-text-dim px-1.5 py-0.5 rounded">{conn.to_entity}</span>
											{/each}
											{#if graphSelectedCard.connections.length > 8}
												<span class="text-[10px] text-text-dim">+{graphSelectedCard.connections.length - 8}</span>
											{/if}
										</div>
									</div>
								{/if}
								<button
									class="mt-3 text-xs text-accent hover:underline"
									on:click={() => { switchTool('library'); selectCardByName(graphSelectedNode?.name ?? ''); graphSelectedNode = null; graphSelectedCard = null; }}
								>View full card</button>
							{:else}
								<p class="text-xs text-text-dim">Card not found.</p>
							{/if}
						</div>
					</div>
				{/if}
			</div>
		{/if}
	</div>
</div>
